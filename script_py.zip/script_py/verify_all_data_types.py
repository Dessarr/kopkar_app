#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk memverifikasi semua jenis data (simpanan, pinjaman, tagihan)
Memastikan semua data sudah sesuai antara Excel dan Database
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

class ComprehensiveDataVerifier:
    def __init__(self, excel_file_path):
        self.excel_file_path = excel_file_path
        self.db_connection = None
        self.excel_data = None
        self.verification_results = {}
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def load_excel_data(self):
        """Load data dari Excel file"""
        try:
            print("📊 Membaca data Excel...")
            self.excel_data = pd.read_excel(
                self.excel_file_path, 
                sheet_name='All Simpanan 2025',
                header=4  # Header di baris ke-5 (0-indexed)
            )
            
            # Bersihkan data yang tidak relevan
            self.excel_data = self.excel_data.dropna(subset=['Unnamed: 1'])
            
            print(f"✅ Data Excel berhasil dimuat: {len(self.excel_data)} baris")
            return True
            
        except Exception as e:
            print(f"❌ Error membaca Excel: {e}")
            return False
    
    def verify_simpanan_data(self):
        """Verifikasi data simpanan"""
        print("\n🔍 VERIFIKASI DATA SIMPANAN")
        print("=" * 50)
        
        # Mapping jenis simpanan
        simpanan_mapping = {
            8: "Tagihan Bulan Lalu",
            31: "Tab. Perumahan", 
            32: "Simpanan Sukarela",
            40: "Simpanan Pokok",
            41: "Simpanan Wajib",
            51: "Simpanan Khusus 1",
            52: "Simpanan Khusus 2"
        }
        
        # Mapping kolom Excel
        excel_columns = {
            8: "Tagihan Bulan Lalu",
            31: "Tab. Perumahan",
            32: "Simpanan Sukarela", 
            40: "Simpanan Pokok",
            41: "Simpanan Wajib",
            51: "Simpanan Khusus 1",
            52: "Simpanan Khusus 2 (THT)"
        }
        
        discrepancies = []
        total_checked = 0
        
        # Ambil semua anggota dari Excel
        excel_members = self.excel_data['Unnamed: 1'].dropna().unique()
        
        for no_ktp in excel_members:
            no_ktp = str(no_ktp)
            if no_ktp == 'nan':
                continue
                
            for jenis_id, jenis_name in simpanan_mapping.items():
                # Ambil dari database
                db_total = self.get_database_total(no_ktp, jenis_id)
                
                # Ambil dari Excel
                excel_value = self.get_excel_value(no_ktp, excel_columns.get(jenis_id))
                
                total_checked += 1
                
                # Cek ketidaksesuaian
                if abs(db_total - excel_value) > 0.01:
                    discrepancies.append({
                        'no_ktp': no_ktp,
                        'jenis_name': jenis_name,
                        'db_total': db_total,
                        'excel_value': excel_value,
                        'difference': db_total - excel_value
                    })
        
        print(f"📊 Total data simpanan dicek: {total_checked}")
        print(f"⚠️  Ketidaksesuaian: {len(discrepancies)}")
        
        if discrepancies:
            print(f"\n📋 Contoh ketidaksesuaian:")
            for disc in discrepancies[:5]:
                print(f"  - {disc['no_ktp']} - {disc['jenis_name']}: DB={disc['db_total']:.2f}, Excel={disc['excel_value']:.2f}")
        
        self.verification_results['simpanan'] = {
            'total_checked': total_checked,
            'discrepancies': len(discrepancies),
            'details': discrepancies
        }
        
        return len(discrepancies) == 0
    
    def verify_pinjaman_data(self):
        """Verifikasi data pinjaman"""
        print("\n🔍 VERIFIKASI DATA PINJAMAN")
        print("=" * 50)
        
        try:
            cursor = self.db_connection.cursor()
            
            # Cek tabel pinjaman yang ada
            cursor.execute("SHOW TABLES LIKE '%pinjam%'")
            pinjaman_tables = cursor.fetchall()
            
            if not pinjaman_tables:
                print("❌ Tidak ada tabel pinjaman ditemukan")
                self.verification_results['pinjaman'] = {
                    'status': 'no_tables',
                    'message': 'Tidak ada tabel pinjaman'
                }
                return False
            
            print(f"📊 Tabel pinjaman ditemukan: {[table[0] for table in pinjaman_tables]}")
            
            # Analisis setiap tabel pinjaman
            pinjaman_summary = {}
            
            for table in pinjaman_tables:
                table_name = table[0]
                print(f"\n📋 Analisis tabel: {table_name}")
                
                # Cek struktur tabel
                cursor.execute(f"DESCRIBE {table_name}")
                columns = cursor.fetchall()
                print(f"  Kolom: {[col[0] for col in columns]}")
                
                # Hitung total record
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                total_records = cursor.fetchone()[0]
                print(f"  Total record: {total_records}")
                
                # Cek data terbaru
                cursor.execute(f"SELECT * FROM {table_name} ORDER BY id DESC LIMIT 3")
                recent_data = cursor.fetchall()
                print(f"  Data terbaru: {len(recent_data)} record")
                
                pinjaman_summary[table_name] = {
                    'total_records': total_records,
                    'columns': [col[0] for col in columns],
                    'recent_data': recent_data
                }
            
            cursor.close()
            
            self.verification_results['pinjaman'] = {
                'status': 'verified',
                'tables': pinjaman_summary
            }
            
            return True
            
        except Exception as e:
            print(f"❌ Error verifikasi pinjaman: {e}")
            self.verification_results['pinjaman'] = {
                'status': 'error',
                'error': str(e)
            }
            return False
    
    def verify_tagihan_data(self):
        """Verifikasi data tagihan"""
        print("\n🔍 VERIFIKASI DATA TAGIHAN")
        print("=" * 50)
        
        try:
            cursor = self.db_connection.cursor()
            
            # Cek tabel tagihan yang ada
            cursor.execute("SHOW TABLES LIKE '%tagih%'")
            tagihan_tables = cursor.fetchall()
            
            if not tagihan_tables:
                print("❌ Tidak ada tabel tagihan ditemukan")
                self.verification_results['tagihan'] = {
                    'status': 'no_tables',
                    'message': 'Tidak ada tabel tagihan'
                }
                return False
            
            print(f"📊 Tabel tagihan ditemukan: {[table[0] for table in tagihan_tables]}")
            
            # Analisis setiap tabel tagihan
            tagihan_summary = {}
            
            for table in tagihan_tables:
                table_name = table[0]
                print(f"\n📋 Analisis tabel: {table_name}")
                
                # Cek struktur tabel
                cursor.execute(f"DESCRIBE {table_name}")
                columns = cursor.fetchall()
                print(f"  Kolom: {[col[0] for col in columns]}")
                
                # Hitung total record
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                total_records = cursor.fetchone()[0]
                print(f"  Total record: {total_records}")
                
                # Cek data terbaru
                cursor.execute(f"SELECT * FROM {table_name} ORDER BY id DESC LIMIT 3")
                recent_data = cursor.fetchall()
                print(f"  Data terbaru: {len(recent_data)} record")
                
                tagihan_summary[table_name] = {
                    'total_records': total_records,
                    'columns': [col[0] for col in columns],
                    'recent_data': recent_data
                }
            
            cursor.close()
            
            self.verification_results['tagihan'] = {
                'status': 'verified',
                'tables': tagihan_summary
            }
            
            return True
            
        except Exception as e:
            print(f"❌ Error verifikasi tagihan: {e}")
            self.verification_results['tagihan'] = {
                'status': 'error',
                'error': str(e)
            }
            return False
    
    def get_database_total(self, no_ktp, jenis_id):
        """Ambil total nominal dari database"""
        try:
            cursor = self.db_connection.cursor()
            
            query = """
            SELECT 
                COALESCE(SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END), 0) - 
                COALESCE(SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END), 0) as total_nominal
            FROM tbl_trans_sp 
            WHERE no_ktp = %s AND jenis_id = %s
            """
            
            cursor.execute(query, (no_ktp, jenis_id))
            result = cursor.fetchone()
            cursor.close()
            
            return float(result[0]) if result and result[0] is not None else 0.0
            
        except Exception as e:
            return 0.0
    
    def get_excel_value(self, no_anggota, column_name):
        """Ambil nilai dari Excel"""
        try:
            row = self.excel_data[self.excel_data['Unnamed: 1'] == no_anggota]
            
            if row.empty or column_name not in self.excel_data.columns:
                return 0.0
            
            value = row[column_name].iloc[0]
            
            if pd.isna(value) or value == '-' or value == '':
                return 0.0
            
            if isinstance(value, str):
                value = value.replace(',', '')
            
            try:
                return float(value)
            except (ValueError, TypeError):
                return 0.0
                
        except Exception as e:
            return 0.0
    
    def generate_comprehensive_report(self):
        """Generate laporan komprehensif"""
        report = f"""
# LAPORAN VERIFIKASI DATA LENGKAP
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## RINGKASAN VERIFIKASI

### 1. DATA SIMPANAN
- Status: {'✅ SESUAI' if self.verification_results.get('simpanan', {}).get('discrepancies', 1) == 0 else '⚠️ ADA KETIDAKSESUAIAN'}
- Total data dicek: {self.verification_results.get('simpanan', {}).get('total_checked', 0)}
- Ketidaksesuaian: {self.verification_results.get('simpanan', {}).get('discrepancies', 0)}

### 2. DATA PINJAMAN
- Status: {self.verification_results.get('pinjaman', {}).get('status', 'TIDAK DICEK')}
- Tabel ditemukan: {len(self.verification_results.get('pinjaman', {}).get('tables', {}))}

### 3. DATA TAGIHAN
- Status: {self.verification_results.get('tagihan', {}).get('status', 'TIDAK DICEK')}
- Tabel ditemukan: {len(self.verification_results.get('tagihan', {}).get('tables', {}))}

## DETAIL HASIL

### Data Simpanan
"""
        
        simpanan_details = self.verification_results.get('simpanan', {})
        if simpanan_details.get('discrepancies', 0) > 0:
            report += f"- Total ketidaksesuaian: {simpanan_details['discrepancies']}\n"
            report += "- Contoh ketidaksesuaian:\n"
            for disc in simpanan_details.get('details', [])[:5]:
                report += f"  - {disc['no_ktp']} - {disc['jenis_name']}: DB={disc['db_total']:.2f}, Excel={disc['excel_value']:.2f}\n"
        else:
            report += "- ✅ Semua data simpanan sudah sesuai\n"
        
        report += f"""
### Data Pinjaman
"""
        
        pinjaman_details = self.verification_results.get('pinjaman', {})
        if pinjaman_details.get('status') == 'verified':
            for table_name, table_info in pinjaman_details.get('tables', {}).items():
                report += f"- {table_name}: {table_info['total_records']} record\n"
        else:
            report += f"- Status: {pinjaman_details.get('status', 'TIDAK DICEK')}\n"
        
        report += f"""
### Data Tagihan
"""
        
        tagihan_details = self.verification_results.get('tagihan', {})
        if tagihan_details.get('status') == 'verified':
            for table_name, table_info in tagihan_details.get('tables', {}).items():
                report += f"- {table_name}: {table_info['total_records']} record\n"
        else:
            report += f"- Status: {tagihan_details.get('status', 'TIDAK DICEK')}\n"
        
        report += f"""
## REKOMENDASI

1. **Data Simpanan**: {'✅ Sudah sesuai' if simpanan_details.get('discrepancies', 1) == 0 else '⚠️ Perlu penyesuaian'}
2. **Data Pinjaman**: {'✅ Tersedia' if pinjaman_details.get('status') == 'verified' else '❌ Tidak tersedia'}
3. **Data Tagihan**: {'✅ Tersedia' if tagihan_details.get('status') == 'verified' else '❌ Tidak tersedia'}

## TIMESTAMP
Laporan ini dibuat pada: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        
        return report
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("🔍 VERIFIKASI DATA LENGKAP")
    print("=" * 50)
    print("Memverifikasi semua jenis data (simpanan, pinjaman, tagihan)")
    print()
    
    # Inisialisasi verifier
    verifier = ComprehensiveDataVerifier('Data Mentah aplikasi.xlsx')
    
    try:
        # Koneksi database
        if not verifier.connect_database():
            return
        
        # Load data Excel
        if not verifier.load_excel_data():
            return
        
        # Verifikasi data simpanan
        simpanan_ok = verifier.verify_simpanan_data()
        
        # Verifikasi data pinjaman
        pinjaman_ok = verifier.verify_pinjaman_data()
        
        # Verifikasi data tagihan
        tagihan_ok = verifier.verify_tagihan_data()
        
        # Generate laporan
        report = verifier.generate_comprehensive_report()
        
        # Simpan laporan
        with open('comprehensive_verification_report.md', 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"\n📄 Laporan lengkap tersimpan di: comprehensive_verification_report.md")
        
        # Ringkasan akhir
        print(f"\n📊 RINGKASAN VERIFIKASI:")
        print("=" * 50)
        print(f"✅ Data Simpanan: {'SESUAI' if simpanan_ok else 'ADA MASALAH'}")
        print(f"✅ Data Pinjaman: {'TERSEDIA' if pinjaman_ok else 'TIDAK TERSEDIA'}")
        print(f"✅ Data Tagihan: {'TERSEDIA' if tagihan_ok else 'TIDAK TERSEDIA'}")
        
    except KeyboardInterrupt:
        print("\n⏹️  Verifikasi dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        verifier.close_connection()

if __name__ == "__main__":
    main()
