#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk membandingkan data simpanan antara Excel dan Database
dan melakukan adjustment jika diperlukan
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys
import os

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

# Mapping jenis_id ke kolom Excel
JENIS_ID_MAPPING = {
    8: 'Tagihan Bulan Lalu',
    31: 'Tab. Perumahan',
    32: 'Simpanan Sukarela', 
    40: 'Simpanan Pokok',
    41: 'Simpanan Wajib',
    51: 'Simpanan Khusus 1',
    52: 'Simpanan Khusus 2 (THT)'
}

# Mapping kolom Excel berdasarkan jenis_id (berdasarkan struktur yang ditemukan)
EXCEL_COLUMN_MAPPING = {
    8: 'Tagihan Bulan Lalu',  # Tidak ada di Excel
    31: 'Tab. Perumahan',
    32: 'Simpanan Sukarela',
    40: 'Simpanan Pokok', 
    41: 'Simpanan Wajib',
    51: 'Simpanan Khusus 1',
    52: 'Simpanan Khusus 2 (THT)'
}

class DataComparator:
    def __init__(self, excel_file_path):
        self.excel_file_path = excel_file_path
        self.db_connection = None
        self.excel_data = None
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def load_excel_data(self):
        """Load data dari Excel file"""
        try:
            # Baca dengan header yang tepat berdasarkan analisis debug
            self.excel_data = pd.read_excel(self.excel_file_path, sheet_name='All Simpanan 2025', header=4)
            print(f"✅ Data Excel berhasil dimuat: {len(self.excel_data)} baris")
            
            # Tampilkan kolom yang tersedia untuk debugging
            print("📋 Kolom yang tersedia di Excel:")
            for col in self.excel_data.columns:
                print(f"  - {col}")
            
            # Bersihkan data - hapus baris yang tidak relevan
            # Gunakan kolom yang ada berdasarkan debug
            if 'Unnamed: 1' in self.excel_data.columns:
                self.excel_data = self.excel_data.dropna(subset=['Unnamed: 1'])
                print(f"📊 Data setelah pembersihan: {len(self.excel_data)} baris")
            
            return True
        except Exception as e:
            print(f"❌ Error membaca Excel: {e}")
            return False
    
    def get_database_totals(self, no_ktp, jenis_id):
        """Ambil total nominal dari database untuk anggota dan jenis simpanan tertentu"""
        try:
            cursor = self.db_connection.cursor()
            
            # Query untuk menghitung total setoran dan penarikan
            query = """
            SELECT 
                SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END) as total_setoran,
                SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END) as total_penarikan,
                (SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END) - 
                 SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END)) as saldo_akhir
            FROM tbl_trans_sp 
            WHERE no_ktp = %s AND jenis_id = %s
            """
            
            cursor.execute(query, (no_ktp, jenis_id))
            result = cursor.fetchone()
            cursor.close()
            
            if result and result[2] is not None:
                return float(result[2])  # Saldo akhir
            else:
                return 0.0
                
        except Exception as e:
            print(f"❌ Error query database: {e}")
            return 0.0
    
    def get_excel_value(self, no_anggota, jenis_id):
        """Ambil nilai dari Excel berdasarkan nomor anggota dan jenis simpanan"""
        try:
            # Cari baris berdasarkan nomor anggota (gunakan kolom yang benar)
            anggota_row = self.excel_data[self.excel_data['Unnamed: 1'] == no_anggota]
            
            if anggota_row.empty:
                return 0.0
            
            # Tentukan kolom berdasarkan jenis_id
            column_name = EXCEL_COLUMN_MAPPING.get(jenis_id)
            if not column_name:
                return 0.0
            
            # Cek apakah kolom ada di Excel
            if column_name not in self.excel_data.columns:
                print(f"⚠️  Kolom '{column_name}' tidak ditemukan di Excel")
                return 0.0
            
            # Ambil nilai dari kolom
            value = anggota_row[column_name].iloc[0]
            
            # Handle nilai kosong atau '-'
            if pd.isna(value) or value == '-' or value == '':
                return 0.0
            
            # Konversi ke float
            try:
                return float(str(value).replace(',', ''))
            except:
                return 0.0
                
        except Exception as e:
            print(f"❌ Error membaca Excel untuk anggota {no_anggota}, jenis {jenis_id}: {e}")
            return 0.0
    
    def insert_adjustment(self, no_ktp, jenis_id, selisih):
        """Insert data adjustment ke database"""
        try:
            cursor = self.db_connection.cursor()
            
            # Format tanggal sekarang
            now = datetime.now()
            
            # Query insert
            insert_query = """
            INSERT INTO tbl_trans_sp 
            (tgl_transaksi, no_ktp, anggota_id, jenis_id, jumlah, keterangan, akun, dk, kas_id, 
             update_data, user_name, nama_penyetor, no_identitas, alamat, id_cabang)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            # Data untuk insert
            values = (
                now,                    # tgl_transaksi
                no_ktp,                 # no_ktp
                None,                   # anggota_id (NULL)
                jenis_id,               # jenis_id
                abs(selisih),           # jumlah (selisih absolut)
                'adjustment',          # keterangan
                'Setoran',             # akun
                'D',                   # dk
                4,                     # kas_id
                None,                  # update_data (NULL)
                None,                  # user_name (NULL)
                None,                  # nama_penyetor (NULL)
                None,                  # no_identitas (NULL)
                None,                  # alamat (NULL)
                None                   # id_cabang (NULL)
            )
            
            cursor.execute(insert_query, values)
            self.db_connection.commit()
            cursor.close()
            
            print(f"✅ Adjustment berhasil: {no_ktp}, jenis {jenis_id}, selisih {selisih:,.0f}")
            return True
            
        except Exception as e:
            print(f"❌ Error insert adjustment: {e}")
            return False
    
    def process_comparison(self):
        """Proses utama perbandingan dan adjustment"""
        print("\n🔄 Memulai proses perbandingan data...")
        
        # Ambil semua nomor anggota dari Excel (gunakan kolom yang benar)
        anggota_list = self.excel_data['Unnamed: 1'].dropna().unique()
        print(f"📊 Ditemukan {len(anggota_list)} anggota di Excel")
        
        total_adjustments = 0
        
        for no_anggota in anggota_list:
            print(f"\n👤 Memproses anggota: {no_anggota}")
            
            # Proses setiap jenis simpanan
            for jenis_id, jenis_nama in JENIS_ID_MAPPING.items():
                # Skip jika jenis_id tidak ada di mapping Excel
                if jenis_id not in EXCEL_COLUMN_MAPPING:
                    continue
                
                # Ambil total dari database
                db_total = self.get_database_totals(no_anggota, jenis_id)
                
                # Ambil nilai dari Excel
                excel_value = self.get_excel_value(no_anggota, jenis_id)
                
                # Skip jika nilai Excel kosong atau 0
                if excel_value == 0:
                    continue
                
                # Hitung selisih
                selisih = excel_value - db_total
                
                # Jika ada selisih, lakukan adjustment
                if abs(selisih) > 0.01:  # Toleransi 0.01 untuk floating point
                    print(f"  📝 {jenis_nama}: DB={db_total:,.0f}, Excel={excel_value:,.0f}, Selisih={selisih:,.0f}")
                    
                    if self.insert_adjustment(no_anggota, jenis_id, selisih):
                        total_adjustments += 1
                else:
                    print(f"  ✅ {jenis_nama}: Sudah sesuai (DB={db_total:,.0f}, Excel={excel_value:,.0f})")
        
        print(f"\n🎉 Proses selesai! Total adjustment: {total_adjustments}")
        return total_adjustments
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("🚀 Script Perbandingan Data Simpanan")
    print("=" * 50)
    
    # Path ke file Excel
    excel_file = "Data Mentah aplikasi.xlsx"
    
    if not os.path.exists(excel_file):
        print(f"❌ File Excel tidak ditemukan: {excel_file}")
        print("Pastikan file 'Data Mentah aplikasi.xlsx' ada di direktori yang sama")
        return
    
    # Inisialisasi comparator
    comparator = DataComparator(excel_file)
    
    try:
        # Koneksi database
        if not comparator.connect_database():
            return
        
        # Load data Excel
        if not comparator.load_excel_data():
            return
        
        # Proses perbandingan
        total_adjustments = comparator.process_comparison()
        
        print(f"\n📊 Ringkasan:")
        print(f"  - Total adjustment dibuat: {total_adjustments}")
        print(f"  - File Excel: {excel_file}")
        print(f"  - Database: {DB_CONFIG['database']}")
        
    except KeyboardInterrupt:
        print("\n⏹️  Proses dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        comparator.close_connection()

if __name__ == "__main__":
    main()
