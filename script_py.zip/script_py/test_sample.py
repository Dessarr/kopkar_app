#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk test dengan data sample sebelum menjalankan script utama
"""

import pandas as pd
import mysql.connector
from datetime import datetime

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

def test_database_connection():
    """Test koneksi database"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        cursor = connection.cursor()
        
        # Test query sederhana
        cursor.execute("SELECT COUNT(*) FROM tbl_trans_sp")
        count = cursor.fetchone()[0]
        print(f"✅ Koneksi database berhasil. Total records di tbl_trans_sp: {count}")
        
        # Test query untuk sample data
        cursor.execute("""
            SELECT no_ktp, jenis_id, SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END) as total_setoran,
                   SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END) as total_penarikan
            FROM tbl_trans_sp 
            WHERE jenis_id IN (32, 40, 41, 51, 52, 31)
            GROUP BY no_ktp, jenis_id 
            LIMIT 5
        """)
        
        results = cursor.fetchall()
        print("\n📊 Sample data dari database:")
        for row in results:
            print(f"  {row[0]} | Jenis {row[1]} | Setoran: {row[2]:,.0f} | Penarikan: {row[3]:,.0f}")
        
        cursor.close()
        connection.close()
        return True
        
    except mysql.connector.Error as err:
        print(f"❌ Error koneksi database: {err}")
        return False

def test_excel_reading():
    """Test membaca file Excel"""
    try:
        excel_file = "Data Mentah aplikasi.xlsx"
        df = pd.read_excel(excel_file, sheet_name='All Simpanan 2025', header=4)
        
        print(f"✅ File Excel berhasil dibaca: {len(df)} baris")
        print("\n📋 Kolom yang tersedia:")
        for col in df.columns:
            print(f"  - {col}")
        
        # Test sample data
        if 'Unnamed: 1' in df.columns:
            sample_anggota = df['Unnamed: 1'].dropna().head(3).tolist()
            print(f"\n👥 Sample nomor anggota: {sample_anggota}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error membaca Excel: {e}")
        return False

def test_sample_comparison():
    """Test perbandingan dengan data sample"""
    try:
        # Load Excel dengan header yang benar
        df = pd.read_excel("Data Mentah aplikasi.xlsx", sheet_name='All Simpanan 2025', header=4)
        
        # Ambil sample anggota
        sample_anggota = df['Unnamed: 1'].dropna().iloc[0]
        print(f"\n🧪 Test dengan anggota sample: {sample_anggota}")
        
        # Koneksi database
        connection = mysql.connector.connect(**DB_CONFIG)
        cursor = connection.cursor()
        
        # Test untuk jenis simpanan 32 (Simpanan Sukarela)
        cursor.execute("""
            SELECT 
                SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END) as total_setoran,
                SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END) as total_penarikan,
                (SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END) - 
                 SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END)) as saldo_akhir
            FROM tbl_trans_sp 
            WHERE no_ktp = %s AND jenis_id = 32
        """, (sample_anggota,))
        
        db_result = cursor.fetchone()
        
        # Ambil nilai dari Excel
        anggota_row = df[df['Unnamed: 1'] == sample_anggota]
        if not anggota_row.empty and 'Simpanan Sukarela' in df.columns:
            excel_value = anggota_row['Simpanan Sukarela'].iloc[0]
            if pd.isna(excel_value) or excel_value == '-':
                excel_value = 0
            else:
                excel_value = float(str(excel_value).replace(',', ''))
        else:
            excel_value = 0
        
        print(f"📊 Hasil perbandingan untuk {sample_anggota}:")
        print(f"  Database saldo: {db_result[2] if db_result[2] else 0:,.0f}")
        print(f"  Excel value: {excel_value:,.0f}")
        
        if db_result[2] and abs(db_result[2] - excel_value) > 0.01:
            selisih = excel_value - db_result[2]
            print(f"  Selisih: {selisih:,.0f} (perlu adjustment)")
        else:
            print(f"  ✅ Data sudah sesuai")
        
        cursor.close()
        connection.close()
        return True
        
    except Exception as e:
        print(f"❌ Error test comparison: {e}")
        return False

def main():
    """Fungsi utama test"""
    print("🧪 Test Script Perbandingan Data")
    print("=" * 40)
    
    # Test 1: Database connection
    print("\n1️⃣ Test koneksi database...")
    if not test_database_connection():
        return
    
    # Test 2: Excel reading
    print("\n2️⃣ Test membaca Excel...")
    if not test_excel_reading():
        return
    
    # Test 3: Sample comparison
    print("\n3️⃣ Test perbandingan sample...")
    if not test_sample_comparison():
        return
    
    print("\n✅ Semua test berhasil! Script siap dijalankan.")
    print("Jalankan 'python compare_and_adjust.py' untuk memulai proses lengkap.")

if __name__ == "__main__":
    main()
