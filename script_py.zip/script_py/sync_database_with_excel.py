#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk menyinkronkan database dengan file Excel
Mengurangi data berlebih di database agar sesuai dengan Excel
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

# Mapping jenis simpanan
JNS_SIMPAN_MAPPING = {
    8: "Tagihan Bulan Lalu",
    31: "Tab. Perumahan", 
    32: "Simpanan Sukarela",
    40: "Simpanan Pokok",
    41: "Simpanan Wajib",
    51: "Simpanan Khusus 1",
    52: "Simpanan Khusus 2"
}

# Mapping kolom Excel
EXCEL_COLUMN_MAPPING = {
    8: "Tagihan Bulan Lalu",
    31: "Tab. Perumahan",
    32: "Simpanan Sukarela", 
    40: "Simpanan Pokok",
    41: "Simpanan Wajib",
    51: "Simpanan Khusus 1",
    52: "Simpanan Khusus 2 (THT)"
}

class DatabaseExcelSync:
    def __init__(self, excel_file_path):
        self.excel_file_path = excel_file_path
        self.db_connection = None
        self.excel_data = None
        self.sync_log = []
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def load_excel_data(self):
        """Load data dari Excel file"""
        try:
            print("📊 Membaca data Excel...")
            self.excel_data = pd.read_excel(
                self.excel_file_path, 
                sheet_name='All Simpanan 2025',
                header=4  # Header di baris ke-5 (0-indexed)
            )
            
            # Bersihkan data yang tidak relevan
            self.excel_data = self.excel_data.dropna(subset=['Unnamed: 1'])
            
            print(f"✅ Data Excel berhasil dimuat: {len(self.excel_data)} baris")
            return True
            
        except Exception as e:
            print(f"❌ Error membaca Excel: {e}")
            return False
    
    def get_excel_value(self, no_anggota, jenis_id):
        """Ambil nilai dari Excel untuk anggota dan jenis simpanan tertentu"""
        try:
            # Cari baris dengan no_anggota yang sesuai
            row = self.excel_data[self.excel_data['Unnamed: 1'] == no_anggota]
            
            if row.empty:
                return 0.0
            
            # Ambil kolom yang sesuai dengan jenis_id
            column_name = EXCEL_COLUMN_MAPPING.get(jenis_id)
            if not column_name:
                return 0.0
            
            # Cek apakah kolom ada di Excel
            if column_name not in self.excel_data.columns:
                return 0.0
            
            value = row[column_name].iloc[0]
            
            # Handle berbagai format data
            if pd.isna(value) or value == '-' or value == '':
                return 0.0
            
            # Konversi ke float, handle koma sebagai pemisah ribuan
            if isinstance(value, str):
                value = value.replace(',', '')
            
            try:
                return float(value)
            except (ValueError, TypeError):
                return 0.0
                
        except Exception as e:
            return 0.0
    
    def get_database_totals(self, no_ktp, jenis_id):
        """Ambil total nominal dari database untuk anggota dan jenis simpanan tertentu"""
        try:
            cursor = self.db_connection.cursor()
            
            # Hitung total dari tbl_trans_sp
            query = """
            SELECT 
                COALESCE(SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END), 0) - 
                COALESCE(SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END), 0) as total_nominal
            FROM tbl_trans_sp 
            WHERE no_ktp = %s AND jenis_id = %s
            """
            
            cursor.execute(query, (no_ktp, jenis_id))
            result = cursor.fetchone()
            cursor.close()
            
            return float(result[0]) if result and result[0] is not None else 0.0
            
        except Exception as e:
            print(f"❌ Error query database untuk {no_ktp}, jenis_id {jenis_id}: {e}")
            return 0.0
    
    def get_excel_members(self):
        """Ambil semua anggota dari Excel"""
        try:
            members = self.excel_data['Unnamed: 1'].dropna().unique()
            return [str(member) for member in members if str(member) != 'nan']
        except Exception as e:
            print(f"❌ Error mengambil anggota dari Excel: {e}")
            return []
    
    def calculate_adjustment_needed(self, no_ktp, jenis_id):
        """Hitung adjustment yang diperlukan untuk menyamakan database dengan Excel"""
        db_total = self.get_database_totals(no_ktp, jenis_id)
        excel_value = self.get_excel_value(no_ktp, jenis_id)
        
        # Hitung selisih (Excel - Database)
        adjustment_needed = excel_value - db_total
        
        return {
            'no_ktp': no_ktp,
            'jenis_id': jenis_id,
            'db_total': db_total,
            'excel_value': excel_value,
            'adjustment_needed': adjustment_needed,
            'needs_adjustment': abs(adjustment_needed) > 0.01
        }
    
    def create_adjustment_record(self, no_ktp, jenis_id, adjustment_amount):
        """Buat record adjustment untuk menyamakan database dengan Excel"""
        try:
            cursor = self.db_connection.cursor()
            
            # Tentukan akun dan dk berdasarkan nilai adjustment
            if adjustment_amount > 0:
                akun = "Setoran"
                dk = "D"
                keterangan = "adjustment - penyesuaian dengan Excel"
            else:
                akun = "Penarikan"
                dk = "K"
                keterangan = "adjustment - pengurangan sesuai Excel"
            
            # Insert adjustment record
            insert_query = """
            INSERT INTO tbl_trans_sp (
                tgl_transaksi, no_ktp, anggota_id, jenis_id, jumlah, 
                keterangan, akun, dk, kas_id, update_data, user_name, 
                nama_penyetor, no_identitas, alamat, id_cabang
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
            """
            
            values = (
                datetime.now(),  # tgl_transaksi
                no_ktp,          # no_ktp
                None,            # anggota_id
                jenis_id,        # jenis_id
                abs(adjustment_amount),  # jumlah (selalu positif)
                keterangan,      # keterangan
                akun,           # akun
                dk,             # dk
                4,              # kas_id
                None,           # update_data
                None,           # user_name
                None,           # nama_penyetor
                None,           # no_identitas
                None,           # alamat
                None            # id_cabang
            )
            
            cursor.execute(insert_query, values)
            cursor.close()
            
            return True
            
        except Exception as e:
            print(f"❌ Error membuat adjustment record: {e}")
            return False
    
    def sync_all_data(self):
        """Sinkronkan semua data database dengan Excel"""
        print("🔄 Memulai sinkronisasi database dengan Excel...")
        print("=" * 60)
        
        # Ambil semua anggota dari Excel
        excel_members = self.get_excel_members()
        print(f"📊 Anggota di Excel: {len(excel_members)}")
        
        total_adjustments = 0
        adjustments_created = 0
        
        for i, no_ktp in enumerate(excel_members, 1):
            if i % 50 == 0:
                print(f"⏳ Progress: {i}/{len(excel_members)} anggota")
            
            member_adjustments = 0
            
            # Periksa setiap jenis simpanan
            for jenis_id, jenis_name in JNS_SIMPAN_MAPPING.items():
                # Hitung adjustment yang diperlukan
                adjustment_info = self.calculate_adjustment_needed(no_ktp, jenis_id)
                
                if adjustment_info['needs_adjustment']:
                    # Buat adjustment record
                    if self.create_adjustment_record(
                        no_ktp, 
                        jenis_id, 
                        adjustment_info['adjustment_needed']
                    ):
                        adjustments_created += 1
                        member_adjustments += 1
                        
                        # Log adjustment
                        self.sync_log.append({
                            'no_ktp': no_ktp,
                            'jenis_id': jenis_id,
                            'jenis_name': jenis_name,
                            'db_total': adjustment_info['db_total'],
                            'excel_value': adjustment_info['excel_value'],
                            'adjustment': adjustment_info['adjustment_needed'],
                            'timestamp': datetime.now()
                        })
            
            if member_adjustments > 0:
                total_adjustments += member_adjustments
                print(f"✅ {no_ktp}: {member_adjustments} adjustment dibuat")
        
        print(f"\n📊 HASIL SINKRONISASI:")
        print("=" * 60)
        print(f"Total anggota diproses: {len(excel_members)}")
        print(f"Total adjustment dibuat: {adjustments_created}")
        print(f"Anggota dengan adjustment: {total_adjustments}")
        
        return {
            'total_members': len(excel_members),
            'total_adjustments': adjustments_created,
            'members_with_adjustments': total_adjustments,
            'sync_log': self.sync_log
        }
    
    def verify_sync_results(self):
        """Verifikasi hasil sinkronisasi"""
        print("\n🔍 Memverifikasi hasil sinkronisasi...")
        print("=" * 60)
        
        excel_members = self.get_excel_members()
        discrepancies = 0
        
        for no_ktp in excel_members[:10]:  # Cek 10 anggota pertama
            for jenis_id, jenis_name in JNS_SIMPAN_MAPPING.items():
                db_total = self.get_database_totals(no_ktp, jenis_id)
                excel_value = self.get_excel_value(no_ktp, jenis_id)
                
                if abs(db_total - excel_value) > 0.01:
                    discrepancies += 1
                    print(f"⚠️  {no_ktp} - {jenis_name}: DB={db_total:.2f}, Excel={excel_value:.2f}")
        
        if discrepancies == 0:
            print("✅ Verifikasi berhasil: Data sudah sinkron!")
        else:
            print(f"⚠️  Masih ada {discrepancies} ketidaksesuaian")
        
        return discrepancies == 0
    
    def generate_sync_report(self, sync_results):
        """Generate laporan sinkronisasi"""
        report = f"""
# LAPORAN SINKRONISASI DATABASE DENGAN EXCEL
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## RINGKASAN
- Total anggota diproses: {sync_results['total_members']}
- Total adjustment dibuat: {sync_results['total_adjustments']}
- Anggota dengan adjustment: {sync_results['members_with_adjustments']}

## DETAIL ADJUSTMENT
"""
        
        for log in sync_results['sync_log'][:20]:  # Tampilkan 20 pertama
            report += f"""
### {log['no_ktp']} - {log['jenis_name']}
- Database: {log['db_total']:.2f}
- Excel: {log['excel_value']:.2f}
- Adjustment: {log['adjustment']:.2f}
- Timestamp: {log['timestamp']}
"""
        
        if len(sync_results['sync_log']) > 20:
            report += f"\n... dan {len(sync_results['sync_log']) - 20} adjustment lainnya"
        
        return report
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("🔄 SINKRONISASI DATABASE DENGAN EXCEL")
    print("=" * 50)
    print("Menyamakan data database dengan file Excel")
    print("Mengurangi data berlebih di database")
    print()
    
    # Inisialisasi sync
    sync = DatabaseExcelSync('Data Mentah aplikasi.xlsx')
    
    try:
        # Koneksi database
        if not sync.connect_database():
            return
        
        # Load data Excel
        if not sync.load_excel_data():
            return
        
        # Konfirmasi sebelum sinkronisasi
        print("⚠️  PERINGATAN: Script ini akan membuat adjustment record di database")
        print("Pastikan Anda sudah backup database sebelum melanjutkan!")
        confirm = input("Lanjutkan sinkronisasi? (y/n): ").lower().strip()
        
        if confirm != 'y':
            print("❌ Sinkronisasi dibatalkan")
            return
        
        # Jalankan sinkronisasi
        sync_results = sync.sync_all_data()
        
        # Verifikasi hasil
        sync.verify_sync_results()
        
        # Generate laporan
        report = sync.generate_sync_report(sync_results)
        
        # Simpan laporan
        with open('sync_report.md', 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"\n📄 Laporan tersimpan di: sync_report.md")
        
    except KeyboardInterrupt:
        print("\n⏹️  Sinkronisasi dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        sync.close_connection()

if __name__ == "__main__":
    main()
