#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk debug struktur Excel secara detail
"""

import pandas as pd

def debug_excel_structure():
    """Debug struktur Excel secara detail"""
    try:
        excel_file = "Data Mentah aplikasi.xlsx"
        
        print("🔍 Debug struktur Excel secara detail...")
        print("=" * 50)
        
        # Baca dengan header yang berbeda dan tampilkan hasil
        for header_row in range(6):
            print(f"\n📊 Header row {header_row}:")
            print("-" * 30)
            
            try:
                df = pd.read_excel(excel_file, sheet_name='All Simpanan 2025', header=header_row)
                print(f"  Jumlah baris: {len(df)}")
                print(f"  Jumlah kolom: {len(df.columns)}")
                
                # Tampilkan semua kolom
                print("  Kolom:")
                for i, col in enumerate(df.columns):
                    print(f"    {i}: {col}")
                
                # Tampilkan beberapa baris pertama
                print("  Sample data (3 baris pertama):")
                for idx in range(min(3, len(df))):
                    row_data = df.iloc[idx]
                    print(f"    Baris {idx}: {dict(row_data.head(5))}")
                
                # Cek apakah ada data yang relevan
                if 'NOMOR ANGGOTA REV' in df.columns:
                    print("  ✅ Kolom 'NOMOR ANGGOTA REV' ditemukan!")
                    # Tampilkan sample data dari kolom ini
                    sample_anggota = df['NOMOR ANGGOTA REV'].dropna().head(3).tolist()
                    print(f"  Sample nomor anggota: {sample_anggota}")
                
                # Cek kolom simpanan
                simpanan_keywords = ['POKOK', 'WAJIB', 'SUKARELA', 'KHUSUS', 'PERUMAHAN']
                simpanan_cols = []
                for col in df.columns:
                    for keyword in simpanan_keywords:
                        if keyword in str(col).upper():
                            simpanan_cols.append(col)
                            break
                
                if simpanan_cols:
                    print(f"  ✅ Kolom simpanan ditemukan: {simpanan_cols}")
                
                print()
                
            except Exception as e:
                print(f"  ❌ Error: {e}")
                continue
        
        return True
        
    except Exception as e:
        print(f"❌ Error debug: {e}")
        return False

def main():
    """Fungsi utama"""
    print("🔍 Debug Struktur Excel Detail")
    print("=" * 40)
    
    if debug_excel_structure():
        print("\n✅ Debug selesai!")
    else:
        print("\n❌ Debug gagal!")

if __name__ == "__main__":
    main()
