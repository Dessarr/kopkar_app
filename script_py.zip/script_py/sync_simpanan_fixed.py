#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script Final Sinkronisasi Simpanan (Fixed)
Flow: Bersihkan data lama → Baca Excel → Insert ke MySQL
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys

# --- KONFIG DATABASE ---
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # isi kalau pakai password
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

def main():
    """Fungsi utama sinkronisasi"""
    print("🔄 SINKRONISASI SIMPANAN FINAL (FIXED)")
    print("=" * 50)
    print("Flow: Bersihkan data lama → Baca Excel → Insert ke MySQL")
    print()
    
    try:
        # --- STEP 1: KONEKSI DATABASE ---
        print("🔌 Menghubungkan ke database...")
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        print("✅ Koneksi database berhasil")
        
        # --- STEP 2: BERSIHKAN DATA LAMA ---
        print("\n🧹 Membersihkan data lama...")
        cursor.execute("TRUNCATE TABLE tbl_trans_sp;")
        conn.commit()
        print("✅ Data lama dihapus (tbl_trans_sp dikosongkan)")
        
        # --- STEP 3: BACA FILE EXCEL ---
        print("\n📊 Membaca file Excel...")
        file_path = "Data Mentah aplikasi.xlsx"
        sheet_name = "All Simpanan 2025"
        
        # Baca Excel dengan header di baris ke-5 (0-indexed = 4)
        df = pd.read_excel(
            file_path, 
            sheet_name=sheet_name, 
            header=4  # Header di baris ke-5
        )
        
        print(f"✅ Excel berhasil dibaca: {len(df)} baris")
        print(f"📋 Kolom yang tersedia: {list(df.columns)}")
        
        # --- STEP 4: BERSIHKAN DATA ---
        print("\n🧽 Membersihkan data...")
        
        # Bersihkan data yang tidak relevan
        df = df.dropna(subset=['Unnamed: 1'])  # Hapus baris tanpa no_anggota
        
        # Ganti nilai '-' dan NaN dengan 0
        df = df.replace("-", 0).fillna(0)
        
        # Pastikan kolom no_anggota adalah string
        df['Unnamed: 1'] = df['Unnamed: 1'].astype(str).str.strip()
        
        # Hapus baris dengan no_anggota kosong atau tidak valid
        df = df[df['Unnamed: 1'] != ""]
        df = df[df['Unnamed: 1'] != "0"]
        df = df[df['Unnamed: 1'] != "nan"]
        
        print(f"✅ Data dibersihkan: {len(df)} baris valid")
        
        # --- STEP 5: MAPPING KOLOM KE JENIS ID ---
        # Mapping berdasarkan kolom yang tersedia di Excel
        kolom_mapping = {
            'Simpanan Pokok': 40,
            'Simpanan Wajib': 41,
            'Simpanan Sukarela': 32,
            'Simpanan Khusus 1': 51,
            'Simpanan Khusus 2 (THT)': 52,
            'Tab. Perumahan': 31
        }
        
        # Cek kolom mana yang tersedia
        available_columns = []
        for kolom, jenis_id in kolom_mapping.items():
            if kolom in df.columns:
                available_columns.append((kolom, jenis_id))
                print(f"✅ Kolom tersedia: {kolom} → jenis_id {jenis_id}")
            else:
                print(f"❌ Kolom tidak tersedia: {kolom}")
        
        if not available_columns:
            print("❌ Tidak ada kolom simpanan yang tersedia!")
            return False
        
        # --- STEP 6: LOOP DAN INSERT ---
        print(f"\n💾 Memulai insert data...")
        
        insert_query = """
        INSERT INTO tbl_trans_sp
        (tgl_transaksi, no_ktp, anggota_id, jenis_id, jumlah, keterangan, akun, dk, kas_id,
         update_data, user_name, nama_penyetor, no_identitas, alamat, id_cabang)
        VALUES (%s, %s, NULL, %s, %s, 'adjustment', 'Setoran', 'D', 4, NULL, NULL, NULL, NULL, NULL, NULL)
        """
        
        count_total = 0
        anggota_processed = 0
        
        for index, row in df.iterrows():
            no_ktp = row['Unnamed: 1']  # Kolom no_anggota
            inserted = 0
            anggota_data = []
            
            # Proses setiap kolom simpanan yang tersedia
            for kolom, jenis_id in available_columns:
                try:
                    jumlah = float(row[kolom])
                except (ValueError, TypeError):
                    jumlah = 0
                
                # Hanya insert jika jumlah > 0
                if jumlah > 0:
                    cursor.execute(insert_query, (datetime.now(), no_ktp, jenis_id, jumlah))
                    inserted += 1
                    count_total += 1
                    
                    # Simpan data untuk log
                    jenis_name = {
                        40: "Pokok",
                        41: "Wajib", 
                        32: "Sukarela",
                        51: "Khusus1",
                        52: "Khusus2",
                        31: "Perumahan"
                    }.get(jenis_id, f"Jenis{jenis_id}")
                    
                    anggota_data.append(f"{jenis_name}={jumlah:,.0f}")
            
            # Tampilkan log jika ada data yang diinsert
            if inserted > 0:
                anggota_processed += 1
                data_str = " | ".join(anggota_data)
                print(f"✅ {no_ktp} | {data_str} | {inserted} rows inserted")
        
        # Commit semua perubahan
        conn.commit()
        
        # --- STEP 7: RINGKASAN HASIL ---
        print(f"\n🎉 SINKRONISASI SELESAI!")
        print("=" * 50)
        print(f"📊 Total anggota diproses: {anggota_processed}")
        print(f"📊 Total baris diinsert: {count_total}")
        print(f"📊 Rata-rata per anggota: {count_total/anggota_processed:.1f} baris" if anggota_processed > 0 else "📊 Rata-rata per anggota: 0 baris")
        
        # Verifikasi data
        print(f"\n🔍 Verifikasi data...")
        cursor.execute("SELECT COUNT(*) FROM tbl_trans_sp")
        total_records = cursor.fetchone()[0]
        print(f"✅ Total record di database: {total_records}")
        
        cursor.execute("SELECT COUNT(DISTINCT no_ktp) FROM tbl_trans_sp")
        unique_members = cursor.fetchone()[0]
        print(f"✅ Anggota unik: {unique_members}")
        
        # Tampilkan statistik per jenis simpanan
        print(f"\n📈 Statistik per jenis simpanan:")
        cursor.execute("""
            SELECT jenis_id, COUNT(*) as count, SUM(jumlah) as total
            FROM tbl_trans_sp 
            GROUP BY jenis_id 
            ORDER BY jenis_id
        """)
        
        jenis_stats = cursor.fetchall()
        for jenis_id, count, total in jenis_stats:
            jenis_name = {
                31: "Tab. Perumahan",
                32: "Simpanan Sukarela", 
                40: "Simpanan Pokok",
                41: "Simpanan Wajib",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2"
            }.get(jenis_id, f"Jenis {jenis_id}")
            
            print(f"  {jenis_name}: {count} record, Total: {total:,.2f}")
        
        print(f"\n✅ Sinkronisasi berhasil diselesaikan!")
        return True
        
    except mysql.connector.Error as e:
        print(f"❌ Error database: {e}")
        return False
    except FileNotFoundError:
        print(f"❌ File Excel tidak ditemukan: {file_path}")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False
    finally:
        if 'conn' in locals():
            conn.close()
            print("🔌 Koneksi database ditutup")

if __name__ == "__main__":
    success = main()
    if success:
        print("\n🎉 Script berhasil dijalankan!")
    else:
        print("\n❌ Script gagal dijalankan!")
        sys.exit(1)
