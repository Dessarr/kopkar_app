#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk memverifikasi keseluruhan data antara Excel dan Database
Memastikan semua data sudah sinkron setelah proses adjustment
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

# Mapping jenis simpanan
JNS_SIMPAN_MAPPING = {
    8: "Tagihan Bulan Lalu",
    31: "Tab. Perumahan", 
    32: "Simpanan Sukarela",
    40: "Simpanan Pokok",
    41: "Simpanan Wajib",
    51: "Simpanan Khusus 1",
    52: "Simpanan Khusus 2"
}

# Mapping kolom Excel
EXCEL_COLUMN_MAPPING = {
    8: "Tagihan Bulan Lalu",
    31: "Tab. Perumahan",
    32: "Simpanan Sukarela", 
    40: "Simpanan Pokok",
    41: "Simpanan Wajib",
    51: "Simpanan Khusus 1",
    52: "Simpanan Khusus 2"
}

class DataVerifier:
    def __init__(self, excel_file_path):
        self.excel_file_path = excel_file_path
        self.db_connection = None
        self.excel_data = None
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def load_excel_data(self):
        """Load data dari Excel file"""
        try:
            print("📊 Membaca data Excel...")
            self.excel_data = pd.read_excel(
                self.excel_file_path, 
                sheet_name='All Simpanan 2025',
                header=4  # Header di baris ke-5 (0-indexed)
            )
            
            # Bersihkan data yang tidak relevan
            self.excel_data = self.excel_data.dropna(subset=['Unnamed: 1'])
            
            print(f"✅ Data Excel berhasil dimuat: {len(self.excel_data)} baris")
            return True
            
        except Exception as e:
            print(f"❌ Error membaca Excel: {e}")
            return False
    
    def get_database_totals(self, no_ktp, jenis_id):
        """Ambil total nominal dari database untuk anggota dan jenis simpanan tertentu"""
        try:
            cursor = self.db_connection.cursor()
            
            # Hitung total dari tbl_trans_sp
            query = """
            SELECT 
                COALESCE(SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END), 0) - 
                COALESCE(SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END), 0) as total_nominal
            FROM tbl_trans_sp 
            WHERE no_ktp = %s AND jenis_id = %s
            """
            
            cursor.execute(query, (no_ktp, jenis_id))
            result = cursor.fetchone()
            cursor.close()
            
            return float(result[0]) if result and result[0] is not None else 0.0
            
        except Exception as e:
            print(f"❌ Error query database untuk {no_ktp}, jenis_id {jenis_id}: {e}")
            return 0.0
    
    def get_excel_value(self, no_anggota, jenis_id):
        """Ambil nilai dari Excel untuk anggota dan jenis simpanan tertentu"""
        try:
            # Cari baris dengan no_anggota yang sesuai
            row = self.excel_data[self.excel_data['Unnamed: 1'] == no_anggota]
            
            if row.empty:
                return 0.0
            
            # Ambil kolom yang sesuai dengan jenis_id
            column_name = EXCEL_COLUMN_MAPPING.get(jenis_id)
            if not column_name:
                return 0.0
            
            # Cek apakah kolom ada di Excel
            if column_name not in self.excel_data.columns:
                return 0.0
            
            value = row[column_name].iloc[0]
            
            # Handle berbagai format data
            if pd.isna(value) or value == '-' or value == '':
                return 0.0
            
            # Konversi ke float, handle koma sebagai pemisah ribuan
            if isinstance(value, str):
                value = value.replace(',', '')
            
            try:
                return float(value)
            except (ValueError, TypeError):
                return 0.0
                
        except Exception as e:
            print(f"❌ Error membaca Excel untuk {no_anggota}, jenis_id {jenis_id}: {e}")
            return 0.0
    
    def get_all_members_from_excel(self):
        """Ambil semua anggota dari Excel"""
        try:
            members = self.excel_data['Unnamed: 1'].dropna().unique()
            return [str(member) for member in members if str(member) != 'nan']
        except Exception as e:
            print(f"❌ Error mengambil anggota dari Excel: {e}")
            return []
    
    def get_all_members_from_database(self):
        """Ambil semua anggota dari database"""
        try:
            cursor = self.db_connection.cursor()
            query = "SELECT DISTINCT no_ktp FROM tbl_trans_sp WHERE no_ktp IS NOT NULL"
            cursor.execute(query)
            results = cursor.fetchall()
            cursor.close()
            return [row[0] for row in results]
        except Exception as e:
            print(f"❌ Error mengambil anggota dari database: {e}")
            return []
    
    def verify_member_data(self, no_ktp):
        """Verifikasi data untuk satu anggota"""
        discrepancies = []
        
        for jenis_id, jenis_name in JNS_SIMPAN_MAPPING.items():
            # Ambil total dari database
            db_total = self.get_database_totals(no_ktp, jenis_id)
            
            # Ambil nilai dari Excel
            excel_value = self.get_excel_value(no_ktp, jenis_id)
            
            # Bandingkan
            if abs(db_total - excel_value) > 0.01:  # Toleransi 0.01 untuk floating point
                discrepancies.append({
                    'jenis_id': jenis_id,
                    'jenis_name': jenis_name,
                    'db_total': db_total,
                    'excel_value': excel_value,
                    'difference': db_total - excel_value
                })
        
        return discrepancies
    
    def run_comprehensive_verification(self):
        """Jalankan verifikasi menyeluruh"""
        print("🔍 Memulai verifikasi menyeluruh data...")
        print("=" * 60)
        
        # Ambil semua anggota dari Excel
        excel_members = self.get_all_members_from_excel()
        print(f"📊 Anggota di Excel: {len(excel_members)}")
        
        # Ambil semua anggota dari database
        db_members = self.get_all_members_from_database()
        print(f"📊 Anggota di Database: {len(db_members)}")
        
        # Gabungkan dan ambil unique members
        all_members = list(set(excel_members + db_members))
        print(f"📊 Total unique anggota: {len(all_members)}")
        
        total_discrepancies = 0
        members_with_issues = []
        
        print(f"\n🔍 Memverifikasi {len(all_members)} anggota...")
        print("-" * 60)
        
        for i, no_ktp in enumerate(all_members, 1):
            if i % 50 == 0:  # Progress indicator
                print(f"⏳ Progress: {i}/{len(all_members)} anggota")
            
            discrepancies = self.verify_member_data(no_ktp)
            
            if discrepancies:
                total_discrepancies += len(discrepancies)
                members_with_issues.append({
                    'no_ktp': no_ktp,
                    'discrepancies': discrepancies
                })
        
        # Tampilkan hasil
        print(f"\n📊 HASIL VERIFIKASI:")
        print("=" * 60)
        print(f"Total anggota diverifikasi: {len(all_members)}")
        print(f"Anggota dengan masalah: {len(members_with_issues)}")
        print(f"Total ketidaksesuaian: {total_discrepancies}")
        
        if members_with_issues:
            print(f"\n⚠️  ANGGOTA DENGAN MASALAH:")
            print("-" * 60)
            
            for member in members_with_issues[:10]:  # Tampilkan 10 pertama
                print(f"\n👤 Anggota: {member['no_ktp']}")
                for disc in member['discrepancies']:
                    print(f"  - {disc['jenis_name']}: DB={disc['db_total']:.2f}, Excel={disc['excel_value']:.2f}, Selisih={disc['difference']:.2f}")
            
            if len(members_with_issues) > 10:
                print(f"\n... dan {len(members_with_issues) - 10} anggota lainnya")
        else:
            print("\n✅ SEMUA DATA SUDAH SESUAI!")
            print("Tidak ada ketidaksesuaian antara Excel dan Database")
        
        return {
            'total_members': len(all_members),
            'members_with_issues': len(members_with_issues),
            'total_discrepancies': total_discrepancies,
            'issues': members_with_issues
        }
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("🔍 VERIFIKASI DATA LENGKAP")
    print("=" * 50)
    print("Memverifikasi keseluruhan data antara Excel dan Database")
    print("Memastikan semua data sudah sinkron setelah adjustment")
    print()
    
    # Inisialisasi verifier
    verifier = DataVerifier('Data Mentah aplikasi.xlsx')
    
    try:
        # Koneksi database
        if not verifier.connect_database():
            return
        
        # Load data Excel
        if not verifier.load_excel_data():
            return
        
        # Jalankan verifikasi
        results = verifier.run_comprehensive_verification()
        
        # Ringkasan akhir
        print(f"\n📈 RINGKASAN AKHIR:")
        print("=" * 50)
        print(f"✅ Total anggota: {results['total_members']}")
        print(f"⚠️  Anggota bermasalah: {results['members_with_issues']}")
        print(f"🔢 Total ketidaksesuaian: {results['total_discrepancies']}")
        
        if results['total_discrepancies'] == 0:
            print("\n🎉 SEMUA DATA SUDAH PERFECT!")
            print("Excel dan Database sudah 100% sinkron")
        else:
            print(f"\n⚠️  Masih ada {results['total_discrepancies']} ketidaksesuaian")
            print("Perlu dilakukan pengecekan lebih lanjut")
        
    except KeyboardInterrupt:
        print("\n⏹️  Verifikasi dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        verifier.close_connection()

if __name__ == "__main__":
    main()
