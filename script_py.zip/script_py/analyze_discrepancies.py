#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk menganalisis ketidaksesuaian antara Excel dan Database
Mencari tahu penyebab dan solusi untuk masalah data
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

# Mapping jenis simpanan
JNS_SIMPAN_MAPPING = {
    8: "Tagihan Bulan Lalu",
    31: "Tab. Perumahan", 
    32: "Simpanan Sukarela",
    40: "Simpanan Pokok",
    41: "Simpanan Wajib",
    51: "Simpanan Khusus 1",
    52: "Simpanan Khusus 2"
}

# Mapping kolom Excel
EXCEL_COLUMN_MAPPING = {
    8: "Tagihan Bulan Lalu",
    31: "Tab. Perumahan",
    32: "Simpanan Sukarela", 
    40: "Simpanan Pokok",
    41: "Simpanan Wajib",
    51: "Simpanan Khusus 1",
    52: "Simpanan Khusus 2"
}

class DiscrepancyAnalyzer:
    def __init__(self, excel_file_path):
        self.excel_file_path = excel_file_path
        self.db_connection = None
        self.excel_data = None
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def load_excel_data(self):
        """Load data dari Excel file"""
        try:
            print("📊 Membaca data Excel...")
            self.excel_data = pd.read_excel(
                self.excel_file_path, 
                sheet_name='All Simpanan 2025',
                header=4  # Header di baris ke-5 (0-indexed)
            )
            
            # Bersihkan data yang tidak relevan
            self.excel_data = self.excel_data.dropna(subset=['Unnamed: 1'])
            
            print(f"✅ Data Excel berhasil dimuat: {len(self.excel_data)} baris")
            print(f"📋 Kolom yang tersedia: {list(self.excel_data.columns)}")
            return True
            
        except Exception as e:
            print(f"❌ Error membaca Excel: {e}")
            return False
    
    def analyze_excel_structure(self):
        """Analisis struktur Excel untuk memahami masalah"""
        print("\n🔍 ANALISIS STRUKTUR EXCEL:")
        print("=" * 50)
        
        # Cek kolom yang ada
        available_columns = list(self.excel_data.columns)
        print(f"📋 Total kolom: {len(available_columns)}")
        
        # Cek kolom simpanan yang tersedia
        simpanan_columns = []
        for jenis_id, column_name in EXCEL_COLUMN_MAPPING.items():
            if column_name in available_columns:
                simpanan_columns.append((jenis_id, column_name))
                print(f"✅ {column_name} (jenis_id {jenis_id})")
            else:
                print(f"❌ {column_name} (jenis_id {jenis_id}) - TIDAK ADA")
        
        # Cek data sample
        print(f"\n📊 Sample data (5 baris pertama):")
        print(self.excel_data[['Unnamed: 1'] + [col for _, col in simpanan_columns]].head())
        
        return simpanan_columns
    
    def analyze_member_coverage(self):
        """Analisis cakupan anggota"""
        print("\n🔍 ANALISIS CAKUPAN ANGGOTA:")
        print("=" * 50)
        
        # Anggota di Excel
        excel_members = set(self.excel_data['Unnamed: 1'].dropna().astype(str))
        print(f"📊 Anggota di Excel: {len(excel_members)}")
        
        # Anggota di Database
        cursor = self.db_connection.cursor()
        cursor.execute("SELECT DISTINCT no_ktp FROM tbl_trans_sp WHERE no_ktp IS NOT NULL")
        db_members = set([row[0] for row in cursor.fetchall()])
        cursor.close()
        print(f"📊 Anggota di Database: {len(db_members)}")
        
        # Anggota yang ada di Excel tapi tidak di Database
        excel_only = excel_members - db_members
        print(f"📊 Hanya di Excel: {len(excel_only)}")
        
        # Anggota yang ada di Database tapi tidak di Excel
        db_only = db_members - excel_members
        print(f"📊 Hanya di Database: {len(db_only)}")
        
        # Anggota yang ada di keduanya
        common = excel_members & db_members
        print(f"📊 Ada di keduanya: {len(common)}")
        
        if len(excel_only) > 0:
            print(f"\n⚠️  Contoh anggota hanya di Excel: {list(excel_only)[:5]}")
        
        if len(db_only) > 0:
            print(f"\n⚠️  Contoh anggota hanya di Database: {list(db_only)[:5]}")
        
        return {
            'excel_members': excel_members,
            'db_members': db_members,
            'excel_only': excel_only,
            'db_only': db_only,
            'common': common
        }
    
    def analyze_discrepancy_patterns(self, sample_size=20):
        """Analisis pola ketidaksesuaian"""
        print(f"\n🔍 ANALISIS POLA KETIDAKSESUAIAN (Sample {sample_size}):")
        print("=" * 60)
        
        # Ambil sample anggota yang ada di keduanya
        cursor = self.db_connection.cursor()
        cursor.execute("""
            SELECT DISTINCT no_ktp 
            FROM tbl_trans_sp 
            WHERE no_ktp IS NOT NULL 
            LIMIT %s
        """, (sample_size,))
        sample_members = [row[0] for row in cursor.fetchall()]
        cursor.close()
        
        patterns = {
            'excel_zero_db_positive': 0,  # Excel 0, DB > 0
            'excel_positive_db_zero': 0,   # Excel > 0, DB 0
            'both_positive_different': 0,  # Keduanya > 0 tapi berbeda
            'both_zero': 0                # Keduanya 0
        }
        
        for no_ktp in sample_members:
            for jenis_id, jenis_name in JNS_SIMPAN_MAPPING.items():
                # Ambil dari database
                cursor = self.db_connection.cursor()
                cursor.execute("""
                    SELECT 
                        COALESCE(SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END), 0) - 
                        COALESCE(SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END), 0) as total_nominal
                    FROM tbl_trans_sp 
                    WHERE no_ktp = %s AND jenis_id = %s
                """, (no_ktp, jenis_id))
                db_result = cursor.fetchone()
                cursor.close()
                db_total = float(db_result[0]) if db_result and db_result[0] is not None else 0.0
                
                # Ambil dari Excel
                excel_value = self.get_excel_value(no_ktp, jenis_id)
                
                # Kategorikan pola
                if excel_value == 0 and db_total > 0:
                    patterns['excel_zero_db_positive'] += 1
                elif excel_value > 0 and db_total == 0:
                    patterns['excel_positive_db_zero'] += 1
                elif excel_value > 0 and db_total > 0 and abs(excel_value - db_total) > 0.01:
                    patterns['both_positive_different'] += 1
                elif excel_value == 0 and db_total == 0:
                    patterns['both_zero'] += 1
        
        print(f"📊 Pola ketidaksesuaian:")
        for pattern, count in patterns.items():
            print(f"  - {pattern}: {count}")
        
        return patterns
    
    def get_excel_value(self, no_anggota, jenis_id):
        """Ambil nilai dari Excel untuk anggota dan jenis simpanan tertentu"""
        try:
            # Cari baris dengan no_anggota yang sesuai
            row = self.excel_data[self.excel_data['Unnamed: 1'] == no_anggota]
            
            if row.empty:
                return 0.0
            
            # Ambil kolom yang sesuai dengan jenis_id
            column_name = EXCEL_COLUMN_MAPPING.get(jenis_id)
            if not column_name:
                return 0.0
            
            # Cek apakah kolom ada di Excel
            if column_name not in self.excel_data.columns:
                return 0.0
            
            value = row[column_name].iloc[0]
            
            # Handle berbagai format data
            if pd.isna(value) or value == '-' or value == '':
                return 0.0
            
            # Konversi ke float, handle koma sebagai pemisah ribuan
            if isinstance(value, str):
                value = value.replace(',', '')
            
            try:
                return float(value)
            except (ValueError, TypeError):
                return 0.0
                
        except Exception as e:
            return 0.0
    
    def suggest_solutions(self):
        """Berikan saran solusi berdasarkan analisis"""
        print(f"\n💡 SARAN SOLUSI:")
        print("=" * 50)
        
        print("1. 🔍 MASALAH UTAMA:")
        print("   - Banyak anggota di database yang tidak ada di Excel")
        print("   - Data Excel mungkin tidak lengkap atau menggunakan format berbeda")
        print("   - Perlu verifikasi mapping kolom Excel")
        
        print("\n2. 🛠️  SOLUSI YANG DISARANKAN:")
        print("   a. Periksa kembali file Excel - pastikan semua anggota tercakup")
        print("   b. Verifikasi nama kolom di Excel sesuai dengan mapping")
        print("   c. Cek apakah ada sheet lain yang berisi data lengkap")
        print("   d. Pertimbangkan untuk menggunakan data database sebagai referensi utama")
        
        print("\n3. 📋 LANGKAH SELANJUTNYA:")
        print("   - Periksa struktur file Excel secara manual")
        print("   - Cek apakah ada sheet lain yang relevan")
        print("   - Verifikasi format data di Excel")
        print("   - Pertimbangkan untuk membuat laporan berdasarkan database")
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("🔍 ANALISIS KETIDAKSESUAIAN DATA")
    print("=" * 50)
    print("Menganalisis penyebab ketidaksesuaian antara Excel dan Database")
    print()
    
    # Inisialisasi analyzer
    analyzer = DiscrepancyAnalyzer('Data Mentah aplikasi.xlsx')
    
    try:
        # Koneksi database
        if not analyzer.connect_database():
            return
        
        # Load data Excel
        if not analyzer.load_excel_data():
            return
        
        # Analisis struktur Excel
        simpanan_columns = analyzer.analyze_excel_structure()
        
        # Analisis cakupan anggota
        coverage = analyzer.analyze_member_coverage()
        
        # Analisis pola ketidaksesuaian
        patterns = analyzer.analyze_discrepancy_patterns()
        
        # Berikan saran solusi
        analyzer.suggest_solutions()
        
    except KeyboardInterrupt:
        print("\n⏹️  Analisis dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        analyzer.close_connection()

if __name__ == "__main__":
    main()
