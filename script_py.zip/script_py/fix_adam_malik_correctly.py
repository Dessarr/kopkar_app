#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script khusus untuk memperbaiki data Adam Malik dengan benar
Berdasarkan data Excel yang seharusnya: Simpanan Khusus 2 = 18.033.766
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

class AdamMalikCorrectFixer:
    def __init__(self, excel_file_path):
        self.excel_file_path = excel_file_path
        self.db_connection = None
        self.excel_data = None
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def load_excel_data(self):
        """Load data dari Excel file"""
        try:
            print("📊 Membaca data Excel...")
            self.excel_data = pd.read_excel(
                self.excel_file_path, 
                sheet_name='All Simpanan 2025',
                header=4  # Header di baris ke-5 (0-indexed)
            )
            
            # Bersihkan data yang tidak relevan
            self.excel_data = self.excel_data.dropna(subset=['Unnamed: 1'])
            
            print(f"✅ Data Excel berhasil dimuat: {len(self.excel_data)} baris")
            return True
            
        except Exception as e:
            print(f"❌ Error membaca Excel: {e}")
            return False
    
    def get_excel_value_for_adam_malik(self):
        """Ambil nilai Excel untuk Adam Malik secara khusus"""
        try:
            # Cari baris Adam Malik (2007120197)
            row = self.excel_data[self.excel_data['Unnamed: 1'] == 2007120197]
            
            if row.empty:
                print("❌ Adam Malik tidak ditemukan di Excel")
                return {}
            
            print("📊 Data Adam Malik di Excel:")
            print(f"  Baris ditemukan: {len(row)}")
            
            # Ambil nilai dari kolom yang relevan
            excel_values = {}
            
            # Cek kolom yang tersedia
            available_columns = list(self.excel_data.columns)
            print(f"  Kolom tersedia: {available_columns}")
            
            # Mapping kolom Excel untuk Adam Malik
            column_mapping = {
                'Simpanan Pokok': 40,
                'Simpanan Wajib': 41,
                'Simpanan Sukarela': 32,
                'Simpanan Khusus 1': 51,
                'Simpanan Khusus 2 (THT)': 52,
                'Tab. Perumahan': 31
            }
            
            for column_name, jenis_id in column_mapping.items():
                if column_name in available_columns:
                    value = row[column_name].iloc[0]
                    
                    # Handle berbagai format data
                    if pd.isna(value) or value == '-' or value == '':
                        excel_values[jenis_id] = 0.0
                    else:
                        if isinstance(value, str):
                            value = value.replace(',', '')
                        try:
                            excel_values[jenis_id] = float(value)
                        except (ValueError, TypeError):
                            excel_values[jenis_id] = 0.0
                    
                    print(f"  {column_name}: {excel_values[jenis_id]:,.2f}")
                else:
                    print(f"  {column_name}: KOLOM TIDAK ADA")
                    excel_values[jenis_id] = 0.0
            
            return excel_values
            
        except Exception as e:
            print(f"❌ Error membaca Excel untuk Adam Malik: {e}")
            return {}
    
    def get_database_totals(self, no_ktp, jenis_id):
        """Ambil total nominal dari database untuk anggota dan jenis simpanan tertentu"""
        try:
            cursor = self.db_connection.cursor()
            
            # Hitung total dari tbl_trans_sp
            query = """
            SELECT 
                COALESCE(SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END), 0) - 
                COALESCE(SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END), 0) as total_nominal
            FROM tbl_trans_sp 
            WHERE no_ktp = %s AND jenis_id = %s
            """
            
            cursor.execute(query, (no_ktp, jenis_id))
            result = cursor.fetchone()
            cursor.close()
            
            return float(result[0]) if result and result[0] is not None else 0.0
            
        except Exception as e:
            print(f"❌ Error query database untuk {no_ktp}, jenis_id {jenis_id}: {e}")
            return 0.0
    
    def get_database_transactions(self, no_ktp, jenis_id):
        """Ambil detail transaksi dari database untuk debugging"""
        try:
            cursor = self.db_connection.cursor()
            
            query = """
            SELECT id, tgl_transaksi, jumlah, dk, keterangan, akun
            FROM tbl_trans_sp 
            WHERE no_ktp = %s AND jenis_id = %s
            ORDER BY tgl_transaksi DESC
            LIMIT 10
            """
            
            cursor.execute(query, (no_ktp, jenis_id))
            results = cursor.fetchall()
            cursor.close()
            
            return results
            
        except Exception as e:
            print(f"❌ Error query detail transaksi untuk {no_ktp}, jenis_id {jenis_id}: {e}")
            return []
    
    def create_correction_record(self, no_ktp, jenis_id, correction_amount, keterangan):
        """Buat record koreksi untuk memperbaiki ketidaksesuaian"""
        try:
            cursor = self.db_connection.cursor()
            
            # Tentukan akun dan dk berdasarkan nilai koreksi
            if correction_amount > 0:
                # Database lebih besar dari Excel, perlu pengurangan
                akun = "Penarikan"
                dk = "K"
            else:
                # Database lebih kecil dari Excel, perlu penambahan
                akun = "Setoran"
                dk = "D"
            
            # Insert koreksi record
            insert_query = """
            INSERT INTO tbl_trans_sp (
                tgl_transaksi, no_ktp, anggota_id, jenis_id, jumlah, 
                keterangan, akun, dk, kas_id, update_data, user_name, 
                nama_penyetor, no_identitas, alamat, id_cabang
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
            """
            
            values = (
                datetime.now(),  # tgl_transaksi
                no_ktp,          # no_ktp
                None,            # anggota_id
                jenis_id,        # jenis_id
                abs(correction_amount),  # jumlah (selalu positif)
                keterangan,      # keterangan
                akun,           # akun
                dk,             # dk
                4,              # kas_id
                None,           # update_data
                None,           # user_name
                None,           # nama_penyetor
                None,           # no_identitas
                None,           # alamat
                None            # id_cabang
            )
            
            cursor.execute(insert_query, values)
            cursor.close()
            
            return True
            
        except Exception as e:
            print(f"❌ Error membuat koreksi record: {e}")
            return False
    
    def fix_adam_malik_correctly(self):
        """Perbaiki data Adam Malik dengan benar"""
        print("\n🎯 MEMPERBAIKI ADAM MALIK DENGAN BENAR")
        print("=" * 60)
        
        no_ktp = "2007120197"
        
        # Ambil data Excel untuk Adam Malik
        excel_values = self.get_excel_value_for_adam_malik()
        
        if not excel_values:
            print("❌ Tidak dapat membaca data Excel untuk Adam Malik")
            return 0
        
        corrections_made = 0
        
        # Jenis simpanan yang perlu dicek
        jenis_to_check = [32, 40, 41, 51, 52]  # Sukarela, Pokok, Wajib, Khusus 1, Khusus 2
        
        for jenis_id in jenis_to_check:
            jenis_name = {
                32: "Simpanan Sukarela",
                40: "Simpanan Pokok", 
                41: "Simpanan Wajib",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2"
            }.get(jenis_id, f"Jenis {jenis_id}")
            
            # Ambil nilai saat ini dari database
            current_db_value = self.get_database_totals(no_ktp, jenis_id)
            target_excel_value = excel_values.get(jenis_id, 0.0)
            
            print(f"\n📊 {jenis_name} (Jenis ID: {jenis_id})")
            print(f"  Database saat ini: {current_db_value:,.2f}")
            print(f"  Excel (target): {target_excel_value:,.2f}")
            
            # Hitung selisih
            difference = current_db_value - target_excel_value
            print(f"  Selisih: {difference:,.2f}")
            
            if abs(difference) > 0.01:  # Ada perbedaan
                print(f"  ⚠️  Perlu koreksi: {difference:,.2f}")
                
                # Tampilkan detail transaksi untuk debugging
                transactions = self.get_database_transactions(no_ktp, jenis_id)
                if transactions:
                    print(f"  📋 Detail transaksi database:")
                    for trans in transactions[:3]:  # Tampilkan 3 terbaru
                        id_trans, tgl, jumlah, dk, keterangan, akun = trans
                        print(f"    ID {id_trans}: {tgl} | {dk} | {jumlah:,.2f} | {keterangan} | {akun}")
                
                # Buat record koreksi
                keterangan = f"koreksi Adam Malik - penyesuaian dengan Excel ({jenis_name})"
                if self.create_correction_record(no_ktp, jenis_id, -difference, keterangan):
                    corrections_made += 1
                    print(f"  ✅ Koreksi berhasil dibuat")
                else:
                    print(f"  ❌ Gagal membuat koreksi")
            else:
                print(f"  ✅ Sudah sesuai")
        
        print(f"\n📊 HASIL PERBAIKAN ADAM MALIK:")
        print(f"  Total koreksi dibuat: {corrections_made}")
        
        return corrections_made
    
    def verify_adam_malik_final(self):
        """Verifikasi hasil akhir Adam Malik"""
        print(f"\n🔍 VERIFIKASI ADAM MALIK SETELAH PERBAIKAN")
        print("=" * 60)
        
        no_ktp = "2007120197"
        
        # Ambil data Excel untuk Adam Malik
        excel_values = self.get_excel_value_for_adam_malik()
        
        if not excel_values:
            print("❌ Tidak dapat membaca data Excel untuk Adam Malik")
            return False
        
        all_correct = True
        
        for jenis_id in [32, 40, 41, 51, 52]:
            jenis_name = {
                32: "Simpanan Sukarela",
                40: "Simpanan Pokok", 
                41: "Simpanan Wajib",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2"
            }.get(jenis_id, f"Jenis {jenis_id}")
            
            db_total = self.get_database_totals(no_ktp, jenis_id)
            excel_value = excel_values.get(jenis_id, 0.0)
            
            print(f"📊 {jenis_name}:")
            print(f"  Database: {db_total:,.2f}")
            print(f"  Excel: {excel_value:,.2f}")
            
            if abs(db_total - excel_value) > 0.01:
                print(f"  ⚠️  MASIH TIDAK SESUAI!")
                all_correct = False
            else:
                print(f"  ✅ SUDAH SESUAI")
        
        if all_correct:
            print(f"\n🎉 ADAM MALIK SUDAH BENAR-BENAR SESUAI DENGAN EXCEL!")
        else:
            print(f"\n⚠️  Adam Malik masih ada ketidaksesuaian")
        
        return all_correct
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("🔧 PERBAIKAN ADAM MALIK YANG BENAR")
    print("=" * 50)
    print("Memperbaiki data Adam Malik sesuai dengan Excel")
    print("Target: Simpanan Khusus 2 = 18.033.766")
    print()
    
    # Inisialisasi fixer
    fixer = AdamMalikCorrectFixer('Data Mentah aplikasi.xlsx')
    
    try:
        # Koneksi database
        if not fixer.connect_database():
            return
        
        # Load data Excel
        if not fixer.load_excel_data():
            return
        
        # Perbaiki Adam Malik dengan benar
        corrections_made = fixer.fix_adam_malik_correctly()
        
        if corrections_made > 0:
            print(f"\n✅ {corrections_made} koreksi berhasil dibuat untuk Adam Malik")
            
            # Verifikasi hasil
            fixer.verify_adam_malik_final()
        else:
            print("\n✅ Adam Malik sudah sesuai, tidak perlu koreksi")
        
    except KeyboardInterrupt:
        print("\n⏹️  Perbaikan dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        fixer.close_connection()

if __name__ == "__main__":
    main()
