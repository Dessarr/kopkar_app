#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk memeriksa struktur file Excel secara detail
Mencari tahu format data dan sheet yang tersedia
"""

import pandas as pd
import openpyxl
from openpyxl import load_workbook
import sys

def examine_excel_file(excel_file_path):
    """Periksa struktur file Excel secara menyeluruh"""
    print("🔍 PEMERIKSAAN STRUKTUR FILE EXCEL")
    print("=" * 60)
    
    try:
        # Load workbook untuk melihat semua sheet
        workbook = load_workbook(excel_file_path, data_only=True)
        print(f"📋 Sheet yang tersedia: {workbook.sheetnames}")
        
        # Periksa setiap sheet
        for sheet_name in workbook.sheetnames:
            print(f"\n📊 SHEET: {sheet_name}")
            print("-" * 40)
            
            # Baca sheet dengan pandas
            try:
                df = pd.read_excel(excel_file_path, sheet_name=sheet_name, header=None)
                print(f"  📏 Ukuran: {df.shape[0]} baris x {df.shape[1]} kolom")
                
                # Cek beberapa baris pertama untuk melihat struktur
                print(f"  📋 5 baris pertama:")
                for i in range(min(5, len(df))):
                    row_data = df.iloc[i].tolist()
                    # Tampilkan hanya kolom yang tidak kosong
                    non_empty = [str(x) for x in row_data if pd.notna(x) and str(x).strip() != '']
                    if non_empty:
                        print(f"    Baris {i+1}: {non_empty[:10]}...")  # Tampilkan 10 kolom pertama
                
                # Cari baris yang mungkin berisi header
                print(f"  🔍 Mencari header yang relevan...")
                for i in range(min(10, len(df))):
                    row = df.iloc[i]
                    row_str = ' '.join([str(x) for x in row if pd.notna(x)])
                    if any(keyword in row_str.lower() for keyword in ['anggota', 'simpanan', 'pokok', 'wajib']):
                        print(f"    Kemungkinan header di baris {i+1}: {row_str[:100]}...")
                
            except Exception as e:
                print(f"  ❌ Error membaca sheet {sheet_name}: {e}")
        
        # Fokus pada sheet "All Simpanan 2025"
        if "All Simpanan 2025" in workbook.sheetnames:
            print(f"\n🎯 ANALISIS DETAIL SHEET 'All Simpanan 2025':")
            print("=" * 60)
            
            # Baca dengan header berbeda untuk melihat struktur
            for header_row in range(6):  # Coba header di baris 0-5
                try:
                    df = pd.read_excel(excel_file_path, sheet_name='All Simpanan 2025', header=header_row)
                    print(f"\n📊 Header di baris {header_row + 1}:")
                    print(f"  Kolom: {list(df.columns)[:10]}...")  # Tampilkan 10 kolom pertama
                    
                    # Cek apakah ada kolom yang relevan
                    relevant_cols = []
                    for col in df.columns:
                        col_str = str(col).lower()
                        if any(keyword in col_str for keyword in ['anggota', 'simpanan', 'pokok', 'wajib', 'sukarela']):
                            relevant_cols.append(col)
                    
                    if relevant_cols:
                        print(f"  ✅ Kolom relevan ditemukan: {relevant_cols}")
                        
                        # Tampilkan sample data
                        if len(df) > 0:
                            print(f"  📋 Sample data (3 baris pertama):")
                            for i in range(min(3, len(df))):
                                sample_row = []
                                for col in relevant_cols[:5]:  # Tampilkan 5 kolom relevan
                                    value = df.iloc[i][col]
                                    sample_row.append(f"{col}={value}")
                                print(f"    Baris {i+1}: {sample_row}")
                    else:
                        print(f"  ❌ Tidak ada kolom relevan ditemukan")
                        
                except Exception as e:
                    print(f"  ❌ Error dengan header {header_row}: {e}")
        
        workbook.close()
        
    except Exception as e:
        print(f"❌ Error memeriksa file Excel: {e}")

def main():
    """Fungsi utama"""
    excel_file = "Data Mentah aplikasi.xlsx"
    examine_excel_file(excel_file)

if __name__ == "__main__":
    main()
