#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script final untuk memperbaiki data Adam Malik
Target: Database harus sama persis dengan Excel
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

class FinalAdamMalikFixer:
    def __init__(self, excel_file_path):
        self.excel_file_path = excel_file_path
        self.db_connection = None
        self.excel_data = None
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def load_excel_data(self):
        """Load data dari Excel file"""
        try:
            print("📊 Membaca data Excel...")
            self.excel_data = pd.read_excel(
                self.excel_file_path, 
                sheet_name='All Simpanan 2025',
                header=4  # Header di baris ke-5 (0-indexed)
            )
            
            # Bersihkan data yang tidak relevan
            self.excel_data = self.excel_data.dropna(subset=['Unnamed: 1'])
            
            print(f"✅ Data Excel berhasil dimuat: {len(self.excel_data)} baris")
            return True
            
        except Exception as e:
            print(f"❌ Error membaca Excel: {e}")
            return False
    
    def get_adam_malik_excel_data(self):
        """Ambil data Excel untuk Adam Malik secara khusus"""
        try:
            # Cari baris Adam Malik (2007120197)
            row = self.excel_data[self.excel_data['Unnamed: 1'] == 2007120197]
            
            if row.empty:
                print("❌ Adam Malik tidak ditemukan di Excel")
                return None
            
            # Ambil nilai dari kolom yang relevan
            excel_data = {
                'no_anggota': 2007120197,
                'nama': 'ADAM MALIK',
                'simpanan_pokok': 0.0,
                'simpanan_wajib': 0.0,
                'simpanan_sukarela': 0.0,
                'simpanan_khusus_1': 0.0,
                'simpanan_khusus_2': 0.0,
                'tab_perumahan': 0.0
            }
            
            # Mapping kolom Excel
            column_mapping = {
                'Simpanan Pokok': 'simpanan_pokok',
                'Simpanan Wajib': 'simpanan_wajib', 
                'Simpanan Sukarela': 'simpanan_sukarela',
                'Simpanan Khusus 1': 'simpanan_khusus_1',
                'Simpanan Khusus 2 (THT)': 'simpanan_khusus_2',
                'Tab. Perumahan': 'tab_perumahan'
            }
            
            for column_name, field_name in column_mapping.items():
                if column_name in self.excel_data.columns:
                    value = row[column_name].iloc[0]
                    
                    # Handle berbagai format data
                    if pd.isna(value) or value == '-' or value == '':
                        excel_data[field_name] = 0.0
                    else:
                        if isinstance(value, str):
                            value = value.replace(',', '')
                        try:
                            excel_data[field_name] = float(value)
                        except (ValueError, TypeError):
                            excel_data[field_name] = 0.0
                else:
                    excel_data[field_name] = 0.0
            
            return excel_data
            
        except Exception as e:
            print(f"❌ Error membaca Excel untuk Adam Malik: {e}")
            return None
    
    def get_adam_malik_database_data(self):
        """Ambil data database untuk Adam Malik"""
        try:
            cursor = self.db_connection.cursor()
            
            # Ambil total untuk setiap jenis simpanan
            query = """
            SELECT jenis_id, 
                   COALESCE(SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END), 0) - 
                   COALESCE(SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END), 0) as total_nominal
            FROM tbl_trans_sp 
            WHERE no_ktp = '2007120197'
            GROUP BY jenis_id
            ORDER BY jenis_id
            """
            
            cursor.execute(query)
            results = cursor.fetchall()
            cursor.close()
            
            # Konversi ke dictionary
            db_data = {}
            for jenis_id, total in results:
                db_data[jenis_id] = total
            
            return db_data
            
        except Exception as e:
            print(f"❌ Error query database untuk Adam Malik: {e}")
            return {}
    
    def create_correction_record(self, no_ktp, jenis_id, correction_amount, keterangan):
        """Buat record koreksi untuk memperbaiki ketidaksesuaian"""
        try:
            cursor = self.db_connection.cursor()
            
            # Tentukan akun dan dk berdasarkan nilai koreksi
            if correction_amount > 0:
                # Database lebih besar dari Excel, perlu pengurangan
                akun = "Penarikan"
                dk = "K"
            else:
                # Database lebih kecil dari Excel, perlu penambahan
                akun = "Setoran"
                dk = "D"
            
            # Insert koreksi record
            insert_query = """
            INSERT INTO tbl_trans_sp (
                tgl_transaksi, no_ktp, anggota_id, jenis_id, jumlah, 
                keterangan, akun, dk, kas_id, update_data, user_name, 
                nama_penyetor, no_identitas, alamat, id_cabang
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
            """
            
            values = (
                datetime.now(),  # tgl_transaksi
                no_ktp,          # no_ktp
                None,            # anggota_id
                jenis_id,        # jenis_id
                abs(correction_amount),  # jumlah (selalu positif)
                keterangan,      # keterangan
                akun,           # akun
                dk,             # dk
                4,              # kas_id
                None,           # update_data
                None,           # user_name
                None,           # nama_penyetor
                None,           # no_identitas
                None,           # alamat
                None            # id_cabang
            )
            
            cursor.execute(insert_query, values)
            cursor.close()
            
            return True
            
        except Exception as e:
            print(f"❌ Error membuat koreksi record: {e}")
            return False
    
    def fix_adam_malik_final(self):
        """Perbaiki data Adam Malik secara final"""
        print("\n🎯 PERBAIKAN FINAL ADAM MALIK")
        print("=" * 60)
        
        # Ambil data Excel
        excel_data = self.get_adam_malik_excel_data()
        if not excel_data:
            return 0
        
        # Ambil data database
        db_data = self.get_adam_malik_database_data()
        
        print(f"📊 Data Adam Malik di Excel:")
        print(f"  Simpanan Pokok: {excel_data['simpanan_pokok']:,.2f}")
        print(f"  Simpanan Wajib: {excel_data['simpanan_wajib']:,.2f}")
        print(f"  Simpanan Sukarela: {excel_data['simpanan_sukarela']:,.2f}")
        print(f"  Simpanan Khusus 1: {excel_data['simpanan_khusus_1']:,.2f}")
        print(f"  Simpanan Khusus 2: {excel_data['simpanan_khusus_2']:,.2f}")
        print(f"  Tab. Perumahan: {excel_data['tab_perumahan']:,.2f}")
        
        print(f"\n📊 Data Adam Malik di Database:")
        for jenis_id, total in db_data.items():
            jenis_name = {
                8: "Tagihan Bulan Lalu",
                31: "Tab. Perumahan",
                32: "Simpanan Sukarela",
                40: "Simpanan Pokok",
                41: "Simpanan Wajib",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2"
            }.get(jenis_id, f"Jenis {jenis_id}")
            print(f"  {jenis_name}: {total:,.2f}")
        
        # Mapping untuk perbandingan
        jenis_mapping = {
            40: 'simpanan_pokok',
            41: 'simpanan_wajib',
            32: 'simpanan_sukarela',
            51: 'simpanan_khusus_1',
            52: 'simpanan_khusus_2',
            31: 'tab_perumahan'
        }
        
        corrections_made = 0
        
        print(f"\n🔧 MEMBUAT KOREKSI:")
        print("-" * 40)
        
        for jenis_id, field_name in jenis_mapping.items():
            jenis_name = {
                40: "Simpanan Pokok",
                41: "Simpanan Wajib",
                32: "Simpanan Sukarela",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2",
                31: "Tab. Perumahan"
            }.get(jenis_id, f"Jenis {jenis_id}")
            
            db_value = db_data.get(jenis_id, 0.0)
            excel_value = excel_data.get(field_name, 0.0)
            difference = db_value - excel_value
            
            print(f"\n📊 {jenis_name} (Jenis ID: {jenis_id})")
            print(f"  Database: {db_value:,.2f}")
            print(f"  Excel: {excel_value:,.2f}")
            print(f"  Selisih: {difference:,.2f}")
            
            if abs(difference) > 0.01:  # Ada perbedaan
                print(f"  ⚠️  Perlu koreksi: {difference:,.2f}")
                
                # Buat record koreksi
                keterangan = f"koreksi final Adam Malik - penyesuaian dengan Excel ({jenis_name})"
                if self.create_correction_record("2007120197", jenis_id, -difference, keterangan):
                    corrections_made += 1
                    print(f"  ✅ Koreksi berhasil dibuat")
                else:
                    print(f"  ❌ Gagal membuat koreksi")
            else:
                print(f"  ✅ Sudah sesuai")
        
        print(f"\n📊 HASIL PERBAIKAN FINAL:")
        print(f"  Total koreksi dibuat: {corrections_made}")
        
        return corrections_made
    
    def verify_final_result(self):
        """Verifikasi hasil akhir"""
        print(f"\n🔍 VERIFIKASI HASIL AKHIR")
        print("=" * 60)
        
        # Ambil data Excel
        excel_data = self.get_adam_malik_excel_data()
        if not excel_data:
            return False
        
        # Ambil data database setelah koreksi
        db_data = self.get_adam_malik_database_data()
        
        # Mapping untuk perbandingan
        jenis_mapping = {
            40: 'simpanan_pokok',
            41: 'simpanan_wajib',
            32: 'simpanan_sukarela',
            51: 'simpanan_khusus_1',
            52: 'simpanan_khusus_2',
            31: 'tab_perumahan'
        }
        
        all_correct = True
        
        print(f"📊 VERIFIKASI FINAL:")
        print("-" * 40)
        
        for jenis_id, field_name in jenis_mapping.items():
            jenis_name = {
                40: "Simpanan Pokok",
                41: "Simpanan Wajib",
                32: "Simpanan Sukarela",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2",
                31: "Tab. Perumahan"
            }.get(jenis_id, f"Jenis {jenis_id}")
            
            db_value = db_data.get(jenis_id, 0.0)
            excel_value = excel_data.get(field_name, 0.0)
            
            print(f"\n📊 {jenis_name}:")
            print(f"  Database: {db_value:,.2f}")
            print(f"  Excel: {excel_value:,.2f}")
            
            if abs(db_value - excel_value) > 0.01:
                print(f"  ⚠️  MASIH TIDAK SESUAI!")
                all_correct = False
            else:
                print(f"  ✅ SUDAH SESUAI")
        
        if all_correct:
            print(f"\n🎉 ADAM MALIK SUDAH BENAR-BENAR SESUAI DENGAN EXCEL!")
            print(f"   Semua data sudah sinkron 100%")
        else:
            print(f"\n⚠️  Adam Malik masih ada ketidaksesuaian")
        
        return all_correct
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("🔧 PERBAIKAN FINAL ADAM MALIK")
    print("=" * 50)
    print("Memperbaiki data Adam Malik agar 100% sesuai dengan Excel")
    print("Target: Semua jenis simpanan harus sama persis")
    print()
    
    # Inisialisasi fixer
    fixer = FinalAdamMalikFixer('Data Mentah aplikasi.xlsx')
    
    try:
        # Koneksi database
        if not fixer.connect_database():
            return
        
        # Load data Excel
        if not fixer.load_excel_data():
            return
        
        # Perbaiki Adam Malik secara final
        corrections_made = fixer.fix_adam_malik_final()
        
        if corrections_made > 0:
            print(f"\n✅ {corrections_made} koreksi berhasil dibuat untuk Adam Malik")
            
            # Verifikasi hasil
            fixer.verify_final_result()
        else:
            print("\n✅ Adam Malik sudah sesuai, tidak perlu koreksi")
        
    except KeyboardInterrupt:
        print("\n⏹️  Perbaikan dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        fixer.close_connection()

if __name__ == "__main__":
    main()
