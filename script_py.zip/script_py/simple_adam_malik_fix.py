#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script sederhana untuk memperbaiki data Adam Malik
Fokus pada Simpanan Khusus 2 yang harus 18.033.766
"""

import mysql.connector
from datetime import datetime

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

def fix_adam_malik_simple():
    """Perbaiki data Adam Malik dengan cara sederhana"""
    print("🔧 PERBAIKAN SEDERHANA ADAM MALIK")
    print("=" * 50)
    
    try:
        # Koneksi database
        db_connection = mysql.connector.connect(**DB_CONFIG)
        print("✅ Koneksi database berhasil")
        
        cursor = db_connection.cursor()
        
        # 1. Cek data Adam Malik saat ini
        print("\n📊 Data Adam Malik saat ini:")
        cursor.execute("""
            SELECT jenis_id, 
                   COALESCE(SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END), 0) - 
                   COALESCE(SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END), 0) as total_nominal
            FROM tbl_trans_sp 
            WHERE no_ktp = '2007120197'
            GROUP BY jenis_id
            ORDER BY jenis_id
        """)
        
        current_data = cursor.fetchall()
        for jenis_id, total in current_data:
            jenis_name = {
                8: "Tagihan Bulan Lalu",
                31: "Tab. Perumahan",
                32: "Simpanan Sukarela",
                40: "Simpanan Pokok",
                41: "Simpanan Wajib",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2"
            }.get(jenis_id, f"Jenis {jenis_id}")
            print(f"  {jenis_name}: {total:,.2f}")
        
        # 2. Target data Adam Malik sesuai Excel
        target_data = {
            40: 10000.0,      # Simpanan Pokok
            41: 11850000.0,   # Simpanan Wajib
            32: 7200000.0,    # Simpanan Sukarela
            51: 0.0,          # Simpanan Khusus 1
            52: 18033766.0,   # Simpanan Khusus 2 (TARGET UTAMA)
            31: 0.0           # Tab. Perumahan
        }
        
        print(f"\n📊 Target data Adam Malik (sesuai Excel):")
        for jenis_id, target in target_data.items():
            jenis_name = {
                40: "Simpanan Pokok",
                41: "Simpanan Wajib",
                32: "Simpanan Sukarela",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2",
                31: "Tab. Perumahan"
            }.get(jenis_id, f"Jenis {jenis_id}")
            print(f"  {jenis_name}: {target:,.2f}")
        
        # 3. Hitung selisih dan buat koreksi
        print(f"\n🔧 MEMBUAT KOREKSI:")
        print("-" * 40)
        
        corrections_made = 0
        
        for jenis_id, target_value in target_data.items():
            # Cari data saat ini
            current_value = 0.0
            for jenis_id_db, total in current_data:
                if jenis_id_db == jenis_id:
                    current_value = total
                    break
            
            selisih = current_value - target_value
            
            jenis_name = {
                40: "Simpanan Pokok",
                41: "Simpanan Wajib",
                32: "Simpanan Sukarela",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2",
                31: "Tab. Perumahan"
            }.get(jenis_id, f"Jenis {jenis_id}")
            
            print(f"\n📊 {jenis_name} (Jenis ID: {jenis_id})")
            print(f"  Database: {current_value:,.2f}")
            print(f"  Excel: {target_value:,.2f}")
            print(f"  Selisih: {selisih:,.2f}")
            
            if abs(selisih) > 0.01:  # Ada perbedaan
                print(f"  ⚠️  Perlu koreksi: {selisih:,.2f}")
                
                # Buat record koreksi
                if selisih > 0:
                    # Database lebih besar, perlu pengurangan
                    akun = "Penarikan"
                    dk = "K"
                    keterangan = f"koreksi Adam Malik - pengurangan sesuai Excel ({jenis_name})"
                else:
                    # Database lebih kecil, perlu penambahan
                    akun = "Setoran"
                    dk = "D"
                    keterangan = f"koreksi Adam Malik - penambahan sesuai Excel ({jenis_name})"
                
                insert_query = """
                INSERT INTO tbl_trans_sp (
                    tgl_transaksi, no_ktp, anggota_id, jenis_id, jumlah, 
                    keterangan, akun, dk, kas_id, update_data, user_name, 
                    nama_penyetor, no_identitas, alamat, id_cabang
                ) VALUES (
                    %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
                )
                """
                
                values = (
                    datetime.now(),  # tgl_transaksi
                    "2007120197",    # no_ktp
                    None,            # anggota_id
                    jenis_id,        # jenis_id
                    abs(selisih),   # jumlah (selalu positif)
                    keterangan,      # keterangan
                    akun,           # akun
                    dk,             # dk
                    4,              # kas_id
                    None,           # update_data
                    None,           # user_name
                    None,           # nama_penyetor
                    None,           # no_identitas
                    None,           # alamat
                    None            # id_cabang
                )
                
                cursor.execute(insert_query, values)
                corrections_made += 1
                print(f"  ✅ Koreksi berhasil dibuat")
            else:
                print(f"  ✅ Sudah sesuai")
        
        # Commit perubahan
        db_connection.commit()
        
        print(f"\n📊 HASIL PERBAIKAN:")
        print(f"  Total koreksi dibuat: {corrections_made}")
        
        # 4. Verifikasi hasil
        print(f"\n🔍 VERIFIKASI HASIL:")
        print("-" * 40)
        
        cursor.execute("""
            SELECT jenis_id, 
                   COALESCE(SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END), 0) - 
                   COALESCE(SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END), 0) as total_nominal
            FROM tbl_trans_sp 
            WHERE no_ktp = '2007120197'
            GROUP BY jenis_id
            ORDER BY jenis_id
        """)
        
        final_data = cursor.fetchall()
        all_correct = True
        
        for jenis_id, total in final_data:
            target_value = target_data.get(jenis_id, 0.0)
            jenis_name = {
                40: "Simpanan Pokok",
                41: "Simpanan Wajib",
                32: "Simpanan Sukarela",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2",
                31: "Tab. Perumahan"
            }.get(jenis_id, f"Jenis {jenis_id}")
            
            print(f"📊 {jenis_name}:")
            print(f"  Database: {total:,.2f}")
            print(f"  Excel: {target_value:,.2f}")
            
            if abs(total - target_value) > 0.01:
                print(f"  ⚠️  MASIH TIDAK SESUAI!")
                all_correct = False
            else:
                print(f"  ✅ SUDAH SESUAI")
        
        if all_correct:
            print(f"\n🎉 ADAM MALIK SUDAH BENAR-BENAR SESUAI DENGAN EXCEL!")
            print(f"   Semua data sudah sinkron 100%")
        else:
            print(f"\n⚠️  Adam Malik masih ada ketidaksesuaian")
        
        cursor.close()
        db_connection.close()
        
        return all_correct
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

if __name__ == "__main__":
    success = fix_adam_malik_simple()
    if success:
        print("\n✅ Perbaikan Adam Malik berhasil!")
    else:
        print("\n❌ Perbaikan Adam Malik gagal!")
