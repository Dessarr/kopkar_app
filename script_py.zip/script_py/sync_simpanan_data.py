#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script Sinkronisasi Data Simpanan dari Excel ke MySQL
====================================================

Tujuan: Sinkronisasi penuh tabel tbl_trans_sp dengan data baru dari Excel
File: Data Mentah Aplikasi.xlsx (sheet All Simpanan 2025)

Author: Generated for Kopkar App
Date: 2025
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys
import os

# --- KONFIGURASI DATABASE ---
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # isi kalau pakai password
    'database': 'hushant1_aok',
    'charset': 'utf8mb4',
    'autocommit': False
}

# --- KONFIGURASI FILE EXCEL ---
EXCEL_FILE = "Data Mentah aplikasi.xlsx"
SHEET_NAME = "All Simpanan 2025"
SKIP_ROWS = 7  # Header dimulai di baris ke-8 (0-indexed = 7)

# --- MAPPING KOLOM EXCEL KE JENIS_ID ---
JENIS_MAPPING = {
    "Simpanan Pokok": 40,
    "Simpanan Wajib": 41,
    "Simpanan Sukarela": 32,
    "Simpanan Khusus 1": 51,
    "Simpanan Khusus 2 (THT)": 52,
    "Tab. Perumahan": 31
}

# --- KOLOM YANG DIPAKAI ---
USECOLS = [
    "NOMOR ANGGOTA REV",
    "Simpanan Pokok",
    "Simpanan Wajib", 
    "Simpanan Sukarela",
    "Simpanan Khusus 1",
    "Simpanan Khusus 2 (THT)",
    "Tab. Perumahan"
]

def connect_database():
    """Koneksi ke database MySQL"""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        print("✅ Koneksi database berhasil")
        return conn
    except mysql.connector.Error as err:
        print(f"❌ Error koneksi database: {err}")
        sys.exit(1)

def clear_old_data(cursor):
    """Bersihkan data lama di tbl_trans_sp"""
    try:
        cursor.execute("TRUNCATE TABLE tbl_trans_sp;")
        print("🧹 Data lama dihapus (tbl_trans_sp dikosongkan)")
        return True
    except mysql.connector.Error as err:
        print(f"❌ Error menghapus data lama: {err}")
        return False

def read_excel_data():
    """Baca data dari Excel"""
    try:
        if not os.path.exists(EXCEL_FILE):
            print(f"❌ File Excel tidak ditemukan: {EXCEL_FILE}")
            sys.exit(1)
            
        print(f"📖 Membaca file Excel: {EXCEL_FILE}")
        print(f"📋 Sheet: {SHEET_NAME}")
        print(f"📊 Skip rows: {SKIP_ROWS}")
        
        df = pd.read_excel(
            EXCEL_FILE, 
            sheet_name=SHEET_NAME, 
            skiprows=SKIP_ROWS, 
            usecols=USECOLS
        )
        
        print(f"📈 Data berhasil dibaca: {len(df)} baris")
        return df
        
    except Exception as err:
        print(f"❌ Error membaca Excel: {err}")
        sys.exit(1)

def clean_data(df):
    """Bersihkan dan validasi data"""
    print("🧽 Membersihkan data...")
    
    # Ganti nilai '-' dan NaN dengan 0
    df = df.replace("-", 0).fillna(0)
    
    # Pastikan NOMOR ANGGOTA REV adalah string
    df["NOMOR ANGGOTA REV"] = df["NOMOR ANGGOTA REV"].astype(str).str.strip()
    
    # Hapus baris dengan NOMOR ANGGOTA REV kosong atau invalid
    df = df[df["NOMOR ANGGOTA REV"].str.len() > 0]
    df = df[df["NOMOR ANGGOTA REV"] != "0"]
    df = df[df["NOMOR ANGGOTA REV"] != "nan"]
    
    print(f"📊 Data bersih: {len(df)} baris valid")
    return df

def insert_data(cursor, df):
    """Insert data ke database"""
    insert_query = """
    INSERT INTO tbl_trans_sp
    (tgl_transaksi, no_ktp, anggota_id, jenis_id, jumlah, keterangan, akun, dk, kas_id,
     update_data, user_name, nama_penyetor, no_identitas, alamat, id_cabang)
    VALUES (%s, %s, NULL, %s, %s, 'adjustment', 'Setoran', 'D', 4, NULL, NULL, NULL, NULL, NULL, NULL)
    """
    
    count_total = 0
    count_anggota = 0
    
    print("\n🔄 Memulai proses insert data...")
    print("=" * 60)
    
    for index, row in df.iterrows():
        no_ktp = row["NOMOR ANGGOTA REV"]
        inserted_rows = 0
        
        # Loop untuk setiap jenis simpanan
        for kolom, jenis_id in JENIS_MAPPING.items():
            try:
                jumlah = float(row[kolom])
            except (ValueError, TypeError):
                jumlah = 0
                
            # Insert hanya jika jumlah > 0
            if jumlah > 0:
                try:
                    cursor.execute(insert_query, (
                        datetime.now(), 
                        no_ktp, 
                        jenis_id, 
                        jumlah
                    ))
                    inserted_rows += 1
                    count_total += 1
                except mysql.connector.Error as err:
                    print(f"❌ Error insert {no_ktp} - {kolom}: {err}")
                    continue
        
        # Log hasil untuk anggota ini
        if inserted_rows > 0:
            count_anggota += 1
            print(f"✅ {no_ktp} → {inserted_rows} baris dimasukkan")
    
    print("=" * 60)
    print(f"📊 Ringkasan:")
    print(f"   • Anggota diproses: {count_anggota}")
    print(f"   • Total baris diinsert: {count_total}")
    
    return count_total

def main():
    """Fungsi utama"""
    print("🚀 SCRIPT SINKRONISASI DATA SIMPANAN")
    print("=" * 50)
    print(f"📅 Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Step 1: Koneksi database
    conn = connect_database()
    cursor = conn.cursor()
    
    try:
        # Step 2: Bersihkan data lama
        if not clear_old_data(cursor):
            return
        
        # Step 3: Baca data Excel
        df = read_excel_data()
        
        # Step 4: Bersihkan data
        df = clean_data(df)
        
        if len(df) == 0:
            print("⚠️  Tidak ada data valid untuk diproses")
            return
        
        # Step 5: Insert data
        total_inserted = insert_data(cursor, df)
        
        # Step 6: Commit transaksi
        conn.commit()
        print(f"\n🎉 Selesai! Total {total_inserted} baris berhasil diinsert ke database.")
        
    except Exception as err:
        print(f"❌ Error dalam proses: {err}")
        conn.rollback()
        print("🔄 Transaksi di-rollback")
        
    finally:
        cursor.close()
        conn.close()
        print("🔌 Koneksi database ditutup")

if __name__ == "__main__":
    main()
