# 📊 Script Sinkronisasi Data Simpanan

Script Python untuk sinkronisasi data simpanan dari Excel ke MySQL database.

## 🎯 Tujuan

Sinkronisasi penuh tabel `tbl_trans_sp` dengan data baru dari Excel `Data Mentah aplikasi.xlsx` (sheet `All Simpanan 2025`).

## 📋 Prerequisites

1. **Python 3.7+** sudah terinstall
2. **MySQL database** dengan tabel `tbl_trans_sp`
3. **File Excel** `Data Mentah aplikasi.xlsx` di folder yang sama

## 🚀 Cara Menjalankan

### Opsi 1: Menggunakan Batch File (Windows)

```bash
run_sync_simpanan.bat
```

### Opsi 2: Manual

```bash
# Install dependencies
pip install -r requirements_sync.txt

# Jalankan script
python sync_simpanan_data.py
```

## ⚙️ Konfigurasi

Edit bagian konfigurasi di `sync_simpanan_data.py`:

```python
# --- KONFIGURASI DATABASE ---
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # isi password MySQL
    'database': 'hushant1_aok',
    'charset': 'utf8mb4',
    'autocommit': False
}
```

## 📊 Mapping Data

| Kolom Excel             | jenis_id | Keterangan              |
| ----------------------- | -------- | ----------------------- |
| Simpanan Pokok          | 40       | Simpanan pokok anggota  |
| Simpanan Wajib          | 41       | Simpanan wajib bulanan  |
| Simpanan Sukarela       | 32       | Simpanan sukarela       |
| Simpanan Khusus 1       | 51       | Simpanan khusus 1       |
| Simpanan Khusus 2 (THT) | 52       | Simpanan khusus 2 (THT) |
| Tab. Perumahan          | 31       | Tabungan perumahan      |

## 🔄 Flow Proses

1. **Koneksi Database** - Koneksi ke MySQL
2. **Bersihkan Data Lama** - `TRUNCATE TABLE tbl_trans_sp`
3. **Baca Excel** - Baca sheet `All Simpanan 2025` mulai baris 8
4. **Bersihkan Data** - Ganti `-` dan `NaN` dengan `0`
5. **Mapping & Insert** - Map kolom ke `jenis_id` dan insert ke DB
6. **Commit** - Simpan perubahan ke database

## 📝 Output

Script akan menampilkan:

-   ✅ Status koneksi database
-   🧹 Konfirmasi data lama dihapus
-   📊 Jumlah data yang dibaca dari Excel
-   ✅ Progress insert per anggota
-   🎉 Ringkasan total data yang diinsert

## ⚠️ Peringatan

-   **Data lama akan dihapus total** (TRUNCATE)
-   Pastikan backup database sebelum menjalankan
-   Pastikan file Excel ada dan format benar
-   Pastikan koneksi database stabil

## 🐛 Troubleshooting

### Error: "File Excel tidak ditemukan"

-   Pastikan file `Data Mentah aplikasi.xlsx` ada di folder yang sama

### Error: "Koneksi database gagal"

-   Periksa konfigurasi database di script
-   Pastikan MySQL server berjalan
-   Periksa username/password database

### Error: "Sheet tidak ditemukan"

-   Pastikan sheet `All Simpanan 2025` ada di Excel
-   Periksa nama sheet (case sensitive)

## 📁 File yang Dibuat

-   `sync_simpanan_data.py` - Script utama
-   `requirements_sync.txt` - Dependencies Python
-   `run_sync_simpanan.bat` - Batch file untuk Windows
-   `README_SYNC.md` - Dokumentasi ini
