# PowerShell script untuk menjalankan perbandingan data
Write-Host "🚀 Memulai Script Perbandingan Data Simpanan" -ForegroundColor Green
Write-Host "=" * 50

# Install dependencies
Write-Host "📦 Menginstall dependencies..." -ForegroundColor Yellow
pip install -r requirements.txt

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Error menginstall dependencies" -ForegroundColor Red
    exit 1
}

Write-Host "✅ Dependencies berhasil diinstall" -ForegroundColor Green

# Jalankan script
Write-Host "🔄 Menjalankan script perbandingan..." -ForegroundColor Yellow
python compare_and_adjust.py

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Script selesai dijalankan" -ForegroundColor Green
} else {
    Write-Host "❌ Script mengalami error" -ForegroundColor Red
}

Write-Host "`nTekan Enter untuk keluar..."
Read-Host
