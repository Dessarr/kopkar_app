#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk menganalisis struktur file Excel
"""

import pandas as pd
import sys

def analyze_excel_structure():
    """Analisis struktur file Excel"""
    try:
        excel_file = "Data Mentah aplikasi.xlsx"
        
        print("🔍 Menganalisis struktur file Excel...")
        print("=" * 50)
        
        # Cek sheet yang tersedia
        xl_file = pd.ExcelFile(excel_file)
        print(f"📋 Sheet yang tersedia: {xl_file.sheet_names}")
        
        # Analisis setiap sheet
        for sheet_name in xl_file.sheet_names:
            print(f"\n📊 Analisis sheet: {sheet_name}")
            print("-" * 30)
            
            # Coba dengan header yang berbeda
            for header_row in [0, 1, 2, 3, 4, 5]:
                try:
                    df = pd.read_excel(excel_file, sheet_name=sheet_name, header=header_row)
                    print(f"\nHeader row {header_row}:")
                    print(f"  Jumlah baris: {len(df)}")
                    print(f"  Jumlah kolom: {len(df.columns)}")
                    
                    # Tampilkan beberapa kolom pertama
                    print(f"  Kolom pertama: {list(df.columns[:5])}")
                    
                    # Cek apakah ada kolom yang mengandung "NOMOR ANGGOTA"
                    anggota_cols = [col for col in df.columns if 'NOMOR' in str(col).upper() or 'ANGGOTA' in str(col).upper()]
                    if anggota_cols:
                        print(f"  ✅ Kolom anggota ditemukan: {anggota_cols}")
                    
                    # Cek apakah ada kolom simpanan
                    simpanan_cols = [col for col in df.columns if 'SIMPANAN' in str(col).upper() or 'POKOK' in str(col).upper() or 'WAJIB' in str(col).upper()]
                    if simpanan_cols:
                        print(f"  ✅ Kolom simpanan ditemukan: {simpanan_cols}")
                    
                    # Jika menemukan kolom yang relevan, tampilkan sample data
                    if anggota_cols and simpanan_cols:
                        print(f"  📝 Sample data (3 baris pertama):")
                        sample_data = df.head(3)
                        for idx, row in sample_data.iterrows():
                            print(f"    Baris {idx}: {dict(row.head(3))}")
                        break
                        
                except Exception as e:
                    print(f"  ❌ Error dengan header {header_row}: {e}")
                    continue
        
        return True
        
    except Exception as e:
        print(f"❌ Error menganalisis Excel: {e}")
        return False

def main():
    """Fungsi utama"""
    print("🔍 Analisis Struktur File Excel")
    print("=" * 40)
    
    if analyze_excel_structure():
        print("\n✅ Analisis selesai!")
    else:
        print("\n❌ Analisis gagal!")

if __name__ == "__main__":
    main()
