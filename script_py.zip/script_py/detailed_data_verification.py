#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk verifikasi detail data dan perbaikan ketidaksesuaian
Khusus untuk menangani kasus seperti Adam Malik yang kelebihan 300.000
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

# Mapping jenis simpanan
JNS_SIMPAN_MAPPING = {
    8: "Tagihan Bulan Lalu",
    31: "Tab. Perumahan", 
    32: "Simpanan Sukarela",
    40: "Simpanan Pokok",
    41: "Simpanan Wajib",
    51: "Simpanan Khusus 1",
    52: "Simpanan Khusus 2"
}

# Mapping kolom Excel
EXCEL_COLUMN_MAPPING = {
    8: "Tagihan Bulan Lalu",
    31: "Tab. Perumahan",
    32: "Simpanan Sukarela", 
    40: "Simpanan Pokok",
    41: "Simpanan Wajib",
    51: "Simpanan Khusus 1",
    52: "Simpanan Khusus 2 (THT)"
}

class DetailedDataVerifier:
    def __init__(self, excel_file_path):
        self.excel_file_path = excel_file_path
        self.db_connection = None
        self.excel_data = None
        self.discrepancies = []
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def load_excel_data(self):
        """Load data dari Excel file"""
        try:
            print("📊 Membaca data Excel...")
            self.excel_data = pd.read_excel(
                self.excel_file_path, 
                sheet_name='All Simpanan 2025',
                header=4  # Header di baris ke-5 (0-indexed)
            )
            
            # Bersihkan data yang tidak relevan
            self.excel_data = self.excel_data.dropna(subset=['Unnamed: 1'])
            
            print(f"✅ Data Excel berhasil dimuat: {len(self.excel_data)} baris")
            return True
            
        except Exception as e:
            print(f"❌ Error membaca Excel: {e}")
            return False
    
    def get_excel_value(self, no_anggota, jenis_id):
        """Ambil nilai dari Excel untuk anggota dan jenis simpanan tertentu"""
        try:
            # Cari baris dengan no_anggota yang sesuai
            row = self.excel_data[self.excel_data['Unnamed: 1'] == no_anggota]
            
            if row.empty:
                return 0.0
            
            # Ambil kolom yang sesuai dengan jenis_id
            column_name = EXCEL_COLUMN_MAPPING.get(jenis_id)
            if not column_name:
                return 0.0
            
            # Cek apakah kolom ada di Excel
            if column_name not in self.excel_data.columns:
                return 0.0
            
            value = row[column_name].iloc[0]
            
            # Handle berbagai format data
            if pd.isna(value) or value == '-' or value == '':
                return 0.0
            
            # Konversi ke float, handle koma sebagai pemisah ribuan
            if isinstance(value, str):
                value = value.replace(',', '')
            
            try:
                return float(value)
            except (ValueError, TypeError):
                return 0.0
                
        except Exception as e:
            return 0.0
    
    def get_database_totals(self, no_ktp, jenis_id):
        """Ambil total nominal dari database untuk anggota dan jenis simpanan tertentu"""
        try:
            cursor = self.db_connection.cursor()
            
            # Hitung total dari tbl_trans_sp
            query = """
            SELECT 
                COALESCE(SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END), 0) - 
                COALESCE(SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END), 0) as total_nominal
            FROM tbl_trans_sp 
            WHERE no_ktp = %s AND jenis_id = %s
            """
            
            cursor.execute(query, (no_ktp, jenis_id))
            result = cursor.fetchone()
            cursor.close()
            
            return float(result[0]) if result and result[0] is not None else 0.0
            
        except Exception as e:
            print(f"❌ Error query database untuk {no_ktp}, jenis_id {jenis_id}: {e}")
            return 0.0
    
    def get_database_transactions(self, no_ktp, jenis_id):
        """Ambil detail transaksi dari database untuk debugging"""
        try:
            cursor = self.db_connection.cursor()
            
            query = """
            SELECT id, tgl_transaksi, jumlah, dk, keterangan, akun
            FROM tbl_trans_sp 
            WHERE no_ktp = %s AND jenis_id = %s
            ORDER BY tgl_transaksi DESC
            """
            
            cursor.execute(query, (no_ktp, jenis_id))
            results = cursor.fetchall()
            cursor.close()
            
            return results
            
        except Exception as e:
            print(f"❌ Error query detail transaksi untuk {no_ktp}, jenis_id {jenis_id}: {e}")
            return []
    
    def check_specific_member(self, no_ktp, member_name=""):
        """Cek data untuk anggota tertentu (seperti Adam Malik)"""
        print(f"\n🔍 MEMERIKSA ANGGOTA: {no_ktp} {member_name}")
        print("=" * 60)
        
        discrepancies = []
        
        for jenis_id, jenis_name in JNS_SIMPAN_MAPPING.items():
            # Ambil total dari database
            db_total = self.get_database_totals(no_ktp, jenis_id)
            
            # Ambil nilai dari Excel
            excel_value = self.get_excel_value(no_ktp, jenis_id)
            
            # Hitung selisih
            difference = db_total - excel_value
            
            print(f"\n📊 {jenis_name} (Jenis ID: {jenis_id})")
            print(f"  Database: {db_total:,.2f}")
            print(f"  Excel: {excel_value:,.2f}")
            print(f"  Selisih: {difference:,.2f}")
            
            if abs(difference) > 0.01:  # Toleransi 0.01
                discrepancies.append({
                    'jenis_id': jenis_id,
                    'jenis_name': jenis_name,
                    'db_total': db_total,
                    'excel_value': excel_value,
                    'difference': difference
                })
                
                print(f"  ⚠️  KETIDAKSESUAIAN DITEMUKAN!")
                
                # Tampilkan detail transaksi untuk debugging
                transactions = self.get_database_transactions(no_ktp, jenis_id)
                if transactions:
                    print(f"  📋 Detail transaksi database:")
                    for trans in transactions[:5]:  # Tampilkan 5 terbaru
                        id_trans, tgl, jumlah, dk, keterangan, akun = trans
                        print(f"    ID {id_trans}: {tgl} | {dk} | {jumlah:,.2f} | {keterangan} | {akun}")
        
        return discrepancies
    
    def find_all_discrepancies(self):
        """Cari semua ketidaksesuaian dalam data"""
        print("\n🔍 MENCARI SEMUA KETIDAKSESUAIAN")
        print("=" * 60)
        
        # Ambil semua anggota dari Excel
        excel_members = self.excel_data['Unnamed: 1'].dropna().unique()
        print(f"📊 Memeriksa {len(excel_members)} anggota...")
        
        all_discrepancies = []
        
        for i, no_ktp in enumerate(excel_members, 1):
            no_ktp = str(no_ktp)
            if no_ktp == 'nan':
                continue
                
            if i % 50 == 0:
                print(f"⏳ Progress: {i}/{len(excel_members)} anggota")
            
            member_discrepancies = []
            
            for jenis_id, jenis_name in JNS_SIMPAN_MAPPING.items():
                db_total = self.get_database_totals(no_ktp, jenis_id)
                excel_value = self.get_excel_value(no_ktp, jenis_id)
                difference = db_total - excel_value
                
                if abs(difference) > 0.01:
                    member_discrepancies.append({
                        'no_ktp': no_ktp,
                        'jenis_id': jenis_id,
                        'jenis_name': jenis_name,
                        'db_total': db_total,
                        'excel_value': excel_value,
                        'difference': difference
                    })
            
            if member_discrepancies:
                all_discrepancies.extend(member_discrepancies)
                print(f"⚠️  {no_ktp}: {len(member_discrepancies)} ketidaksesuaian")
        
        return all_discrepancies
    
    def create_correction_record(self, no_ktp, jenis_id, correction_amount):
        """Buat record koreksi untuk memperbaiki ketidaksesuaian"""
        try:
            cursor = self.db_connection.cursor()
            
            # Tentukan akun dan dk berdasarkan nilai koreksi
            if correction_amount > 0:
                # Database lebih besar dari Excel, perlu pengurangan
                akun = "Penarikan"
                dk = "K"
                keterangan = "koreksi - pengurangan sesuai Excel"
            else:
                # Database lebih kecil dari Excel, perlu penambahan
                akun = "Setoran"
                dk = "D"
                keterangan = "koreksi - penambahan sesuai Excel"
            
            # Insert koreksi record
            insert_query = """
            INSERT INTO tbl_trans_sp (
                tgl_transaksi, no_ktp, anggota_id, jenis_id, jumlah, 
                keterangan, akun, dk, kas_id, update_data, user_name, 
                nama_penyetor, no_identitas, alamat, id_cabang
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
            """
            
            values = (
                datetime.now(),  # tgl_transaksi
                no_ktp,          # no_ktp
                None,            # anggota_id
                jenis_id,        # jenis_id
                abs(correction_amount),  # jumlah (selalu positif)
                keterangan,      # keterangan
                akun,           # akun
                dk,             # dk
                4,              # kas_id
                None,           # update_data
                None,           # user_name
                None,           # nama_penyetor
                None,           # no_identitas
                None,           # alamat
                None            # id_cabang
            )
            
            cursor.execute(insert_query, values)
            cursor.close()
            
            return True
            
        except Exception as e:
            print(f"❌ Error membuat koreksi record: {e}")
            return False
    
    def fix_discrepancies(self, discrepancies):
        """Perbaiki ketidaksesuaian yang ditemukan"""
        print(f"\n🔧 MEMPERBAIKI {len(discrepancies)} KETIDAKSESUAIAN")
        print("=" * 60)
        
        fixed_count = 0
        
        for disc in discrepancies:
            no_ktp = disc['no_ktp']
            jenis_id = disc['jenis_id']
            jenis_name = disc['jenis_name']
            difference = disc['difference']
            
            print(f"\n🔧 Memperbaiki {no_ktp} - {jenis_name}")
            print(f"  Selisih: {difference:,.2f}")
            
            # Buat record koreksi
            if self.create_correction_record(no_ktp, jenis_id, -difference):
                fixed_count += 1
                print(f"  ✅ Koreksi berhasil dibuat")
            else:
                print(f"  ❌ Gagal membuat koreksi")
        
        print(f"\n📊 HASIL PERBAIKAN:")
        print(f"  Total ketidaksesuaian: {len(discrepancies)}")
        print(f"  Berhasil diperbaiki: {fixed_count}")
        print(f"  Gagal diperbaiki: {len(discrepancies) - fixed_count}")
        
        return fixed_count
    
    def verify_corrections(self):
        """Verifikasi bahwa koreksi berhasil"""
        print(f"\n🔍 VERIFIKASI HASIL KOREKSI")
        print("=" * 60)
        
        # Ambil semua anggota dari Excel
        excel_members = self.excel_data['Unnamed: 1'].dropna().unique()
        remaining_discrepancies = 0
        
        for no_ktp in excel_members[:10]:  # Cek 10 anggota pertama
            no_ktp = str(no_ktp)
            if no_ktp == 'nan':
                continue
                
            for jenis_id, jenis_name in JNS_SIMPAN_MAPPING.items():
                db_total = self.get_database_totals(no_ktp, jenis_id)
                excel_value = self.get_excel_value(no_ktp, jenis_id)
                
                if abs(db_total - excel_value) > 0.01:
                    remaining_discrepancies += 1
                    print(f"⚠️  {no_ktp} - {jenis_name}: DB={db_total:.2f}, Excel={excel_value:.2f}")
        
        if remaining_discrepancies == 0:
            print("✅ Verifikasi berhasil: Semua data sudah sesuai!")
        else:
            print(f"⚠️  Masih ada {remaining_discrepancies} ketidaksesuaian")
        
        return remaining_discrepancies == 0
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("🔍 VERIFIKASI DETAIL DATA")
    print("=" * 50)
    print("Memeriksa dan memperbaiki ketidaksesuaian data")
    print("Khusus untuk kasus seperti Adam Malik")
    print()
    
    # Inisialisasi verifier
    verifier = DetailedDataVerifier('Data Mentah aplikasi.xlsx')
    
    try:
        # Koneksi database
        if not verifier.connect_database():
            return
        
        # Load data Excel
        if not verifier.load_excel_data():
            return
        
        # Cek Adam Malik secara khusus
        print("🎯 MEMERIKSA ADAM MALIK (2007120197)")
        adam_discrepancies = verifier.check_specific_member("2007120197", "ADAM MALIK")
        
        if adam_discrepancies:
            print("\n⚠️  DITEMUKAN KETIDAKSESUAIAN PADA ADAM MALIK!")
            for disc in adam_discrepancies:
                print(f"  - {disc['jenis_name']}: Selisih {disc['difference']:,.2f}")
        else:
            print("✅ Data Adam Malik sudah sesuai")
        
        # Cari semua ketidaksesuaian
        all_discrepancies = verifier.find_all_discrepancies()
        
        if all_discrepancies:
            print(f"\n⚠️  DITEMUKAN {len(all_discrepancies)} KETIDAKSESUAIAN")
            
            # Tampilkan 10 ketidaksesuaian terbesar
            sorted_discrepancies = sorted(all_discrepancies, key=lambda x: abs(x['difference']), reverse=True)
            print(f"\n📋 10 Ketidaksesuaian Terbesar:")
            for i, disc in enumerate(sorted_discrepancies[:10], 1):
                print(f"  {i}. {disc['no_ktp']} - {disc['jenis_name']}: Selisih {disc['difference']:,.2f}")
            
            # Konfirmasi perbaikan
            print(f"\n⚠️  Akan memperbaiki {len(all_discrepancies)} ketidaksesuaian")
            confirm = input("Lanjutkan perbaikan? (y/n): ").lower().strip()
            
            if confirm == 'y':
                # Perbaiki ketidaksesuaian
                fixed_count = verifier.fix_discrepancies(all_discrepancies)
                
                # Verifikasi hasil
                verifier.verify_corrections()
            else:
                print("❌ Perbaikan dibatalkan")
        else:
            print("✅ Tidak ada ketidaksesuaian ditemukan")
        
    except KeyboardInterrupt:
        print("\n⏹️  Verifikasi dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        verifier.close_connection()

if __name__ == "__main__":
    main()
