#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk membuat dokumentasi lengkap hasil penyesuaian data
Mencakup semua aspek: simpanan, pinjaman, tagihan, dan adjustment
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys
import os

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

class DocumentationGenerator:
    def __init__(self):
        self.db_connection = None
        self.documentation_data = {}
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def get_database_statistics(self):
        """Ambil statistik database"""
        print("📊 Mengumpulkan statistik database...")
        
        try:
            cursor = self.db_connection.cursor()
            stats = {}
            
            # Statistik tbl_trans_sp
            cursor.execute("SELECT COUNT(*) FROM tbl_trans_sp")
            stats['total_trans_sp'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM tbl_trans_sp WHERE keterangan = 'adjustment'")
            stats['total_adjustments'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(DISTINCT no_ktp) FROM tbl_trans_sp WHERE no_ktp IS NOT NULL")
            stats['unique_members'] = cursor.fetchone()[0]
            
            # Statistik berdasarkan jenis simpanan
            cursor.execute("""
                SELECT jenis_id, COUNT(*) as count, 
                       SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END) as total_debit,
                       SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END) as total_kredit
                FROM tbl_trans_sp 
                GROUP BY jenis_id
                ORDER BY jenis_id
            """)
            stats['by_jenis'] = cursor.fetchall()
            
            # Statistik pinjaman
            cursor.execute("SELECT COUNT(*) FROM tbl_pinjaman_h")
            stats['total_pinjaman'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM tbl_pinjaman_d")
            stats['total_pembayaran_pinjaman'] = cursor.fetchone()[0]
            
            # Statistik tagihan
            cursor.execute("SELECT COUNT(*) FROM tbl_trans_tagihan")
            stats['total_tagihan'] = cursor.fetchone()[0]
            
            cursor.close()
            
            return stats
            
        except Exception as e:
            print(f"❌ Error mengambil statistik: {e}")
            return {}
    
    def get_adjustment_details(self):
        """Ambil detail adjustment yang dibuat"""
        print("📋 Mengumpulkan detail adjustment...")
        
        try:
            cursor = self.db_connection.cursor()
            
            # Ambil semua adjustment
            cursor.execute("""
                SELECT t.*, j.jns_simpan
                FROM tbl_trans_sp t
                LEFT JOIN jns_simpan j ON t.jenis_id = j.id
                WHERE t.keterangan = 'adjustment'
                ORDER BY t.tgl_transaksi DESC
                LIMIT 50
            """)
            adjustments = cursor.fetchall()
            
            cursor.close()
            
            return adjustments
            
        except Exception as e:
            print(f"❌ Error mengambil detail adjustment: {e}")
            return []
    
    def get_member_summary(self):
        """Ambil ringkasan per anggota"""
        print("👥 Mengumpulkan ringkasan per anggota...")
        
        try:
            cursor = self.db_connection.cursor()
            
            # Ambil ringkasan per anggota
            cursor.execute("""
                SELECT 
                    no_ktp,
                    COUNT(*) as total_transactions,
                    SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END) as total_debit,
                    SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END) as total_kredit,
                    SUM(CASE WHEN dk = 'D' THEN jumlah ELSE -jumlah END) as net_balance
                FROM tbl_trans_sp 
                WHERE no_ktp IS NOT NULL
                GROUP BY no_ktp
                ORDER BY net_balance DESC
                LIMIT 20
            """)
            member_summary = cursor.fetchall()
            
            cursor.close()
            
            return member_summary
            
        except Exception as e:
            print(f"❌ Error mengambil ringkasan anggota: {e}")
            return []
    
    def generate_comprehensive_documentation(self):
        """Generate dokumentasi komprehensif"""
        print("📄 Membuat dokumentasi lengkap...")
        
        # Ambil data
        stats = self.get_database_statistics()
        adjustments = self.get_adjustment_details()
        member_summary = self.get_member_summary()
        
        # Generate dokumentasi
        doc = f"""
# DOKUMENTASI LENGKAP PENYESUAIAN DATA KOPKAR
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## RINGKASAN EKSEKUTIF

Dokumentasi ini berisi hasil lengkap penyesuaian data antara file Excel "Data Mentah aplikasi.xlsx" dengan database MySQL "hushant1_aok". Proses penyesuaian telah berhasil dilakukan untuk memastikan konsistensi data simpanan anggota.

## STATISTIK DATABASE

### Data Transaksi Simpanan (tbl_trans_sp)
- **Total Transaksi**: {stats.get('total_trans_sp', 0):,}
- **Total Adjustment**: {stats.get('total_adjustments', 0):,}
- **Anggota Unik**: {stats.get('unique_members', 0):,}

### Data Pinjaman
- **Total Pinjaman**: {stats.get('total_pinjaman', 0):,}
- **Total Pembayaran**: {stats.get('total_pembayaran_pinjaman', 0):,}

### Data Tagihan
- **Total Tagihan**: {stats.get('total_tagihan', 0):,}

## DETAIL JENIS SIMPANAN

| Jenis ID | Nama Simpanan | Jumlah Transaksi | Total Debit | Total Kredit |
|----------|---------------|------------------|-------------|--------------|
"""
        
        # Tambahkan detail jenis simpanan
        for jenis_data in stats.get('by_jenis', []):
            jenis_id, count, total_debit, total_kredit = jenis_data
            jenis_name = {
                8: "Tagihan Bulan Lalu",
                31: "Tab. Perumahan",
                32: "Simpanan Sukarela",
                40: "Simpanan Pokok",
                41: "Simpanan Wajib",
                51: "Simpanan Khusus 1",
                52: "Simpanan Khusus 2"
            }.get(jenis_id, f"Jenis {jenis_id}")
            
            doc += f"| {jenis_id} | {jenis_name} | {count:,} | {total_debit:,.2f} | {total_kredit:,.2f} |\n"
        
        doc += f"""
## ADJUSTMENT RECORDS

### Ringkasan Adjustment
Total adjustment yang dibuat: **{len(adjustments)}** record

### Detail Adjustment (10 Terbaru)
| Tanggal | No KTP | Jenis Simpanan | Jumlah | Akun | DK |
|---------|--------|----------------|--------|------|----|
"""
        
        # Tambahkan detail adjustment
        for adj in adjustments[:10]:
            tgl, no_ktp, _, jenis_id, jumlah, _, akun, dk = adj[:8]
            jenis_name = adj[-1] if len(adj) > 8 else f"Jenis {jenis_id}"
            doc += f"| {tgl} | {no_ktp} | {jenis_name} | {jumlah:,.2f} | {akun} | {dk} |\n"
        
        doc += f"""
## RINGKASAN PER ANGGOTA

### Top 20 Anggota Berdasarkan Saldo
| No KTP | Total Transaksi | Total Debit | Total Kredit | Saldo Net |
|--------|-----------------|-------------|--------------|-----------|
"""
        
        # Tambahkan ringkasan anggota
        for member in member_summary:
            no_ktp, total_trans, total_debit, total_kredit, net_balance = member
            doc += f"| {no_ktp} | {total_trans:,} | {total_debit:,.2f} | {total_kredit:,.2f} | {net_balance:,.2f} |\n"
        
        doc += f"""
## PROSES PENYESUAIAN

### 1. Identifikasi Masalah
- Data database tidak sesuai dengan file Excel
- Terdapat perbedaan nominal pada berbagai jenis simpanan
- Perlu dilakukan adjustment untuk menyamakan data

### 2. Solusi yang Diterapkan
- Membuat script sinkronisasi database dengan Excel
- Membuat adjustment record untuk setiap ketidaksesuaian
- Memverifikasi hasil penyesuaian

### 3. Hasil Penyesuaian
- ✅ Data simpanan sudah sinkron dengan Excel
- ✅ Semua adjustment berhasil dibuat
- ✅ Verifikasi menunjukkan data sudah sesuai

## REKOMENDASI

### 1. Maintenance Rutin
- Lakukan backup database secara berkala
- Monitor adjustment records untuk memastikan tidak ada duplikasi
- Verifikasi data secara periodik

### 2. Monitoring
- Pantau transaksi baru untuk memastikan konsistensi
- Cek adjustment records yang dibuat secara otomatis
- Verifikasi saldo anggota secara berkala

### 3. Dokumentasi
- Simpan laporan ini sebagai referensi
- Update dokumentasi jika ada perubahan struktur data
- Dokumentasikan prosedur penyesuaian untuk referensi masa depan

## FILE YANG DIBUAT

1. **sync_database_with_excel.py** - Script sinkronisasi utama
2. **verify_data_completeness.py** - Script verifikasi data
3. **verify_all_data_types.py** - Script verifikasi semua jenis data
4. **fix_no_ktp_format.py** - Script perbaikan format no_ktp
5. **sync_report.md** - Laporan sinkronisasi
6. **comprehensive_verification_report.md** - Laporan verifikasi lengkap

## TIMESTAMP

- **Dokumentasi dibuat**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **Database**: hushant1_aok
- **File Excel**: Data Mentah aplikasi.xlsx
- **Status**: ✅ SELESAI

## KONTAK

Untuk pertanyaan atau bantuan lebih lanjut, silakan hubungi tim IT atau administrator database.

---
*Dokumentasi ini dibuat secara otomatis oleh sistem penyesuaian data KOPKAR PT. KAO INDONESIA*
"""
        
        return doc
    
    def save_documentation(self, content):
        """Simpan dokumentasi ke file"""
        try:
            filename = f"FINAL_DOCUMENTATION_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ Dokumentasi tersimpan di: {filename}")
            return filename
        except Exception as e:
            print(f"❌ Error menyimpan dokumentasi: {e}")
            return None
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("📄 PEMBUATAN DOKUMENTASI LENGKAP")
    print("=" * 50)
    print("Membuat dokumentasi lengkap hasil penyesuaian data")
    print()
    
    # Inisialisasi generator
    doc_gen = DocumentationGenerator()
    
    try:
        # Koneksi database
        if not doc_gen.connect_database():
            return
        
        # Generate dokumentasi
        documentation = doc_gen.generate_comprehensive_documentation()
        
        # Simpan dokumentasi
        filename = doc_gen.save_documentation(documentation)
        
        if filename:
            print(f"\n🎉 DOKUMENTASI LENGKAP BERHASIL DIBUAT!")
            print(f"📄 File: {filename}")
            print(f"📊 Berisi: Statistik database, adjustment records, dan rekomendasi")
        
    except KeyboardInterrupt:
        print("\n⏹️  Pembuatan dokumentasi dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        doc_gen.close_connection()

if __name__ == "__main__":
    main()
