#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script untuk memperbaiki format no_ktp yang salah pada record dengan keterangan "adjustment"
Menghapus .0 dari format no_ktp yang salah
"""

import mysql.connector
from datetime import datetime
import sys

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

class NoKtpFormatter:
    def __init__(self):
        self.db_connection = None
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def find_incorrect_format_records(self):
        """Cari record dengan format no_ktp yang salah"""
        try:
            cursor = self.db_connection.cursor()
            
            # Query untuk mencari record dengan keterangan "adjustment" dan no_ktp yang mengandung .0
            query = """
            SELECT id, no_ktp, keterangan, tgl_transaksi, jenis_id, jumlah
            FROM tbl_trans_sp 
            WHERE keterangan = 'adjustment' 
            AND no_ktp LIKE '%.0'
            ORDER BY id
            """
            
            cursor.execute(query)
            results = cursor.fetchall()
            cursor.close()
            
            print(f"📊 Ditemukan {len(results)} record dengan format no_ktp yang salah")
            
            if results:
                print("\n📋 Record yang akan diperbaiki:")
                print("-" * 80)
                print(f"{'ID':<8} {'No KTP (Salah)':<15} {'Keterangan':<12} {'Tgl Transaksi':<20} {'Jenis ID':<8} {'Jumlah':<12}")
                print("-" * 80)
                
                for row in results:
                    print(f"{row[0]:<8} {row[1]:<15} {row[2]:<12} {str(row[3]):<20} {row[4]:<8} {row[5]:<12}")
            
            return results
            
        except Exception as e:
            print(f"❌ Error mencari record: {e}")
            return []
    
    def fix_no_ktp_format(self, records):
        """Perbaiki format no_ktp pada record yang dipilih"""
        if not records:
            print("⚠️  Tidak ada record untuk diperbaiki")
            return 0
        
        try:
            cursor = self.db_connection.cursor()
            fixed_count = 0
            
            print(f"\n🔧 Memulai perbaikan format no_ktp...")
            
            for record in records:
                record_id = record[0]
                old_no_ktp = record[1]
                
                # Hapus .0 dari no_ktp
                new_no_ktp = old_no_ktp.replace('.0', '')
                
                # Update record
                update_query = """
                UPDATE tbl_trans_sp 
                SET no_ktp = %s 
                WHERE id = %s
                """
                
                cursor.execute(update_query, (new_no_ktp, record_id))
                
                print(f"✅ ID {record_id}: {old_no_ktp} → {new_no_ktp}")
                fixed_count += 1
            
            # Commit perubahan
            self.db_connection.commit()
            cursor.close()
            
            print(f"\n🎉 Berhasil memperbaiki {fixed_count} record")
            return fixed_count
            
        except Exception as e:
            print(f"❌ Error memperbaiki format: {e}")
            return 0
    
    def verify_fixes(self):
        """Verifikasi bahwa perbaikan berhasil"""
        try:
            cursor = self.db_connection.cursor()
            
            # Cek apakah masih ada record dengan format salah
            query = """
            SELECT COUNT(*) 
            FROM tbl_trans_sp 
            WHERE keterangan = 'adjustment' 
            AND no_ktp LIKE '%.0'
            """
            
            cursor.execute(query)
            remaining_count = cursor.fetchone()[0]
            cursor.close()
            
            if remaining_count == 0:
                print("✅ Verifikasi berhasil: Tidak ada lagi record dengan format no_ktp yang salah")
                return True
            else:
                print(f"⚠️  Masih ada {remaining_count} record dengan format yang salah")
                return False
                
        except Exception as e:
            print(f"❌ Error verifikasi: {e}")
            return False
    
    def show_summary(self):
        """Tampilkan ringkasan data adjustment"""
        try:
            cursor = self.db_connection.cursor()
            
            # Total record adjustment
            query_total = """
            SELECT COUNT(*) 
            FROM tbl_trans_sp 
            WHERE keterangan = 'adjustment'
            """
            cursor.execute(query_total)
            total_adjustment = cursor.fetchone()[0]
            
            # Record dengan format yang benar
            query_correct = """
            SELECT COUNT(*) 
            FROM tbl_trans_sp 
            WHERE keterangan = 'adjustment' 
            AND no_ktp NOT LIKE '%.0'
            """
            cursor.execute(query_correct)
            correct_format = cursor.fetchone()[0]
            
            # Record dengan format yang salah (seharusnya 0 setelah perbaikan)
            query_incorrect = """
            SELECT COUNT(*) 
            FROM tbl_trans_sp 
            WHERE keterangan = 'adjustment' 
            AND no_ktp LIKE '%.0'
            """
            cursor.execute(query_incorrect)
            incorrect_format = cursor.fetchone()[0]
            
            cursor.close()
            
            print(f"\n📊 Ringkasan Data Adjustment:")
            print(f"  - Total record adjustment: {total_adjustment}")
            print(f"  - Format benar: {correct_format}")
            print(f"  - Format salah: {incorrect_format}")
            
        except Exception as e:
            print(f"❌ Error ringkasan: {e}")
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("🔧 Script Perbaikan Format no_ktp")
    print("=" * 50)
    print("Memperbaiki format no_ktp pada record dengan keterangan 'adjustment'")
    print("Menghapus .0 dari format yang salah (contoh: 2007120077.0 → 2007120077)")
    print()
    
    # Inisialisasi formatter
    formatter = NoKtpFormatter()
    
    try:
        # Koneksi database
        if not formatter.connect_database():
            return
        
        # Tampilkan ringkasan awal
        print("📊 Ringkasan data sebelum perbaikan:")
        formatter.show_summary()
        
        # Cari record dengan format salah
        incorrect_records = formatter.find_incorrect_format_records()
        
        if not incorrect_records:
            print("✅ Tidak ada record dengan format no_ktp yang salah")
            return
        
        # Konfirmasi sebelum memperbaiki
        print(f"\n⚠️  Akan memperbaiki {len(incorrect_records)} record")
        confirm = input("Lanjutkan perbaikan? (y/n): ").lower().strip()
        
        if confirm != 'y':
            print("❌ Perbaikan dibatalkan")
            return
        
        # Perbaiki format
        fixed_count = formatter.fix_no_ktp_format(incorrect_records)
        
        if fixed_count > 0:
            # Verifikasi perbaikan
            formatter.verify_fixes()
            
            # Tampilkan ringkasan akhir
            print("\n📊 Ringkasan data setelah perbaikan:")
            formatter.show_summary()
        
    except KeyboardInterrupt:
        print("\n⏹️  Proses dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        formatter.close_connection()

if __name__ == "__main__":
    main()
