#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script khusus untuk memperbaiki data Adam Malik dan anggota lainnya
yang tidak sesuai dengan Excel
"""

import pandas as pd
import mysql.connector
from datetime import datetime
import sys

# Konfigurasi Database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # Sesuaikan dengan password MySQL Anda
    'database': 'hushant1_aok',
    'charset': 'utf8mb4'
}

# Mapping jenis simpanan
JNS_SIMPAN_MAPPING = {
    8: "Tagihan Bulan Lalu",
    31: "Tab. Perumahan", 
    32: "Simpanan Sukarela",
    40: "Simpanan Pokok",
    41: "Simpanan Wajib",
    51: "Simpanan Khusus 1",
    52: "Simpanan Khusus 2"
}

# Mapping kolom Excel
EXCEL_COLUMN_MAPPING = {
    8: "Tagihan Bulan Lalu",
    31: "Tab. Perumahan",
    32: "Simpanan Sukarela", 
    40: "Simpanan Pokok",
    41: "Simpanan Wajib",
    51: "Simpanan Khusus 1",
    52: "Simpanan Khusus 2 (THT)"
}

class AdamMalikFixer:
    def __init__(self, excel_file_path):
        self.excel_file_path = excel_file_path
        self.db_connection = None
        self.excel_data = None
        
    def connect_database(self):
        """Koneksi ke database MySQL"""
        try:
            self.db_connection = mysql.connector.connect(**DB_CONFIG)
            print("✅ Koneksi database berhasil")
            return True
        except mysql.connector.Error as err:
            print(f"❌ Error koneksi database: {err}")
            return False
    
    def load_excel_data(self):
        """Load data dari Excel file"""
        try:
            print("📊 Membaca data Excel...")
            self.excel_data = pd.read_excel(
                self.excel_file_path, 
                sheet_name='All Simpanan 2025',
                header=4  # Header di baris ke-5 (0-indexed)
            )
            
            # Bersihkan data yang tidak relevan
            self.excel_data = self.excel_data.dropna(subset=['Unnamed: 1'])
            
            print(f"✅ Data Excel berhasil dimuat: {len(self.excel_data)} baris")
            return True
            
        except Exception as e:
            print(f"❌ Error membaca Excel: {e}")
            return False
    
    def get_excel_value(self, no_anggota, jenis_id):
        """Ambil nilai dari Excel untuk anggota dan jenis simpanan tertentu"""
        try:
            # Cari baris dengan no_anggota yang sesuai
            row = self.excel_data[self.excel_data['Unnamed: 1'] == no_anggota]
            
            if row.empty:
                return 0.0
            
            # Ambil kolom yang sesuai dengan jenis_id
            column_name = EXCEL_COLUMN_MAPPING.get(jenis_id)
            if not column_name:
                return 0.0
            
            # Cek apakah kolom ada di Excel
            if column_name not in self.excel_data.columns:
                return 0.0
            
            value = row[column_name].iloc[0]
            
            # Handle berbagai format data
            if pd.isna(value) or value == '-' or value == '':
                return 0.0
            
            # Konversi ke float, handle koma sebagai pemisah ribuan
            if isinstance(value, str):
                value = value.replace(',', '')
            
            try:
                return float(value)
            except (ValueError, TypeError):
                return 0.0
                
        except Exception as e:
            return 0.0
    
    def get_database_totals(self, no_ktp, jenis_id):
        """Ambil total nominal dari database untuk anggota dan jenis simpanan tertentu"""
        try:
            cursor = self.db_connection.cursor()
            
            # Hitung total dari tbl_trans_sp
            query = """
            SELECT 
                COALESCE(SUM(CASE WHEN dk = 'D' THEN jumlah ELSE 0 END), 0) - 
                COALESCE(SUM(CASE WHEN dk = 'K' THEN jumlah ELSE 0 END), 0) as total_nominal
            FROM tbl_trans_sp 
            WHERE no_ktp = %s AND jenis_id = %s
            """
            
            cursor.execute(query, (no_ktp, jenis_id))
            result = cursor.fetchone()
            cursor.close()
            
            return float(result[0]) if result and result[0] is not None else 0.0
            
        except Exception as e:
            print(f"❌ Error query database untuk {no_ktp}, jenis_id {jenis_id}: {e}")
            return 0.0
    
    def fix_adam_malik_specifically(self):
        """Perbaiki data Adam Malik secara khusus"""
        print("\n🎯 MEMPERBAIKI ADAM MALIK (2007120197)")
        print("=" * 60)
        
        no_ktp = "2007120197"
        corrections_made = 0
        
        # Data yang seharusnya ada di Excel (berdasarkan gambar yang Anda tunjukkan)
        expected_values = {
            32: 0.0,      # Simpanan Sukarela: 0 (tidak ada di Excel)
            40: 0.0,      # Simpanan Pokok: 0 (tidak ada di Excel)  
            41: 0.0,      # Simpanan Wajib: 0 (tidak ada di Excel)
            52: 18033766.0  # Simpanan Khusus 2: 18.033.766 (sesuai Excel)
        }
        
        for jenis_id, expected_value in expected_values.items():
            jenis_name = JNS_SIMPAN_MAPPING.get(jenis_id, f"Jenis {jenis_id}")
            
            # Ambil nilai saat ini dari database
            current_db_value = self.get_database_totals(no_ktp, jenis_id)
            
            print(f"\n📊 {jenis_name} (Jenis ID: {jenis_id})")
            print(f"  Database saat ini: {current_db_value:,.2f}")
            print(f"  Excel (target): {expected_value:,.2f}")
            
            # Hitung selisih
            difference = current_db_value - expected_value
            print(f"  Selisih: {difference:,.2f}")
            
            if abs(difference) > 0.01:  # Ada perbedaan
                print(f"  ⚠️  Perlu koreksi: {difference:,.2f}")
                
                # Buat record koreksi
                if self.create_correction_record(no_ktp, jenis_id, -difference):
                    corrections_made += 1
                    print(f"  ✅ Koreksi berhasil dibuat")
                else:
                    print(f"  ❌ Gagal membuat koreksi")
            else:
                print(f"  ✅ Sudah sesuai")
        
        print(f"\n📊 HASIL PERBAIKAN ADAM MALIK:")
        print(f"  Total koreksi dibuat: {corrections_made}")
        
        return corrections_made
    
    def find_all_members_with_discrepancies(self):
        """Cari semua anggota yang tidak sesuai dengan Excel"""
        print("\n🔍 MENCARI SEMUA ANGGOTA YANG TIDAK SESUAI")
        print("=" * 60)
        
        # Ambil semua anggota dari Excel
        excel_members = self.excel_data['Unnamed: 1'].dropna().unique()
        print(f"📊 Memeriksa {len(excel_members)} anggota...")
        
        members_with_issues = []
        
        for i, no_ktp in enumerate(excel_members, 1):
            no_ktp = str(no_ktp)
            if no_ktp == 'nan':
                continue
                
            if i % 50 == 0:
                print(f"⏳ Progress: {i}/{len(excel_members)} anggota")
            
            member_issues = []
            
            for jenis_id, jenis_name in JNS_SIMPAN_MAPPING.items():
                db_total = self.get_database_totals(no_ktp, jenis_id)
                excel_value = self.get_excel_value(no_ktp, jenis_id)
                difference = db_total - excel_value
                
                if abs(difference) > 0.01:
                    member_issues.append({
                        'jenis_id': jenis_id,
                        'jenis_name': jenis_name,
                        'db_total': db_total,
                        'excel_value': excel_value,
                        'difference': difference
                    })
            
            if member_issues:
                members_with_issues.append({
                    'no_ktp': no_ktp,
                    'issues': member_issues
                })
                print(f"⚠️  {no_ktp}: {len(member_issues)} ketidaksesuaian")
        
        return members_with_issues
    
    def create_correction_record(self, no_ktp, jenis_id, correction_amount):
        """Buat record koreksi untuk memperbaiki ketidaksesuaian"""
        try:
            cursor = self.db_connection.cursor()
            
            # Tentukan akun dan dk berdasarkan nilai koreksi
            if correction_amount > 0:
                # Database lebih besar dari Excel, perlu pengurangan
                akun = "Penarikan"
                dk = "K"
                keterangan = "koreksi - pengurangan sesuai Excel"
            else:
                # Database lebih kecil dari Excel, perlu penambahan
                akun = "Setoran"
                dk = "D"
                keterangan = "koreksi - penambahan sesuai Excel"
            
            # Insert koreksi record
            insert_query = """
            INSERT INTO tbl_trans_sp (
                tgl_transaksi, no_ktp, anggota_id, jenis_id, jumlah, 
                keterangan, akun, dk, kas_id, update_data, user_name, 
                nama_penyetor, no_identitas, alamat, id_cabang
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
            """
            
            values = (
                datetime.now(),  # tgl_transaksi
                no_ktp,          # no_ktp
                None,            # anggota_id
                jenis_id,        # jenis_id
                abs(correction_amount),  # jumlah (selalu positif)
                keterangan,      # keterangan
                akun,           # akun
                dk,             # dk
                4,              # kas_id
                None,           # update_data
                None,           # user_name
                None,           # nama_penyetor
                None,           # no_identitas
                None,           # alamat
                None            # id_cabang
            )
            
            cursor.execute(insert_query, values)
            cursor.close()
            
            return True
            
        except Exception as e:
            print(f"❌ Error membuat koreksi record: {e}")
            return False
    
    def fix_all_discrepancies(self, members_with_issues):
        """Perbaiki semua ketidaksesuaian yang ditemukan"""
        print(f"\n🔧 MEMPERBAIKI SEMUA KETIDAKSESUAIAN")
        print("=" * 60)
        
        total_corrections = 0
        
        for member in members_with_issues:
            no_ktp = member['no_ktp']
            issues = member['issues']
            
            print(f"\n🔧 Memperbaiki {no_ktp} ({len(issues)} ketidaksesuaian)")
            
            for issue in issues:
                jenis_id = issue['jenis_id']
                jenis_name = issue['jenis_name']
                difference = issue['difference']
                
                print(f"  - {jenis_name}: Koreksi {difference:,.2f}")
                
                if self.create_correction_record(no_ktp, jenis_id, -difference):
                    total_corrections += 1
                    print(f"    ✅ Berhasil")
                else:
                    print(f"    ❌ Gagal")
        
        print(f"\n📊 HASIL PERBAIKAN KESELURUHAN:")
        print(f"  Total koreksi dibuat: {total_corrections}")
        
        return total_corrections
    
    def verify_final_results(self):
        """Verifikasi hasil akhir"""
        print(f"\n🔍 VERIFIKASI HASIL AKHIR")
        print("=" * 60)
        
        # Cek Adam Malik secara khusus
        print("🎯 Memverifikasi Adam Malik...")
        adam_issues = 0
        
        for jenis_id, jenis_name in JNS_SIMPAN_MAPPING.items():
            db_total = self.get_database_totals("2007120197", jenis_id)
            excel_value = self.get_excel_value("2007120197", jenis_id)
            
            if abs(db_total - excel_value) > 0.01:
                adam_issues += 1
                print(f"  ⚠️  {jenis_name}: DB={db_total:.2f}, Excel={excel_value:.2f}")
        
        if adam_issues == 0:
            print("  ✅ Adam Malik sudah sesuai dengan Excel")
        else:
            print(f"  ⚠️  Adam Malik masih ada {adam_issues} ketidaksesuaian")
        
        # Cek beberapa anggota lainnya
        excel_members = self.excel_data['Unnamed: 1'].dropna().unique()[:5]
        total_issues = 0
        
        for no_ktp in excel_members:
            no_ktp = str(no_ktp)
            if no_ktp == 'nan':
                continue
                
            member_issues = 0
            for jenis_id in JNS_SIMPAN_MAPPING.keys():
                db_total = self.get_database_totals(no_ktp, jenis_id)
                excel_value = self.get_excel_value(no_ktp, jenis_id)
                
                if abs(db_total - excel_value) > 0.01:
                    member_issues += 1
            
            if member_issues > 0:
                total_issues += member_issues
                print(f"  ⚠️  {no_ktp}: {member_issues} ketidaksesuaian")
        
        if total_issues == 0:
            print("✅ Semua data sudah sesuai dengan Excel!")
        else:
            print(f"⚠️  Masih ada {total_issues} ketidaksesuaian")
        
        return total_issues == 0
    
    def close_connection(self):
        """Tutup koneksi database"""
        if self.db_connection:
            self.db_connection.close()
            print("🔌 Koneksi database ditutup")

def main():
    """Fungsi utama"""
    print("🔧 PERBAIKAN DATA ADAM MALIK DAN LAINNYA")
    print("=" * 50)
    print("Memperbaiki ketidaksesuaian data dengan Excel")
    print("Khusus untuk Adam Malik dan anggota lainnya")
    print()
    
    # Inisialisasi fixer
    fixer = AdamMalikFixer('Data Mentah aplikasi.xlsx')
    
    try:
        # Koneksi database
        if not fixer.connect_database():
            return
        
        # Load data Excel
        if not fixer.load_excel_data():
            return
        
        # Perbaiki Adam Malik secara khusus
        adam_corrections = fixer.fix_adam_malik_specifically()
        
        # Cari anggota lain yang bermasalah
        members_with_issues = fixer.find_all_members_with_discrepancies()
        
        if members_with_issues:
            print(f"\n⚠️  DITEMUKAN {len(members_with_issues)} ANGGOTA DENGAN MASALAH")
            
            # Tampilkan beberapa contoh
            for i, member in enumerate(members_with_issues[:5], 1):
                no_ktp = member['no_ktp']
                issues = member['issues']
                print(f"  {i}. {no_ktp}: {len(issues)} ketidaksesuaian")
                for issue in issues[:2]:  # Tampilkan 2 ketidaksesuaian pertama
                    print(f"     - {issue['jenis_name']}: Selisih {issue['difference']:,.2f}")
            
            if len(members_with_issues) > 5:
                print(f"     ... dan {len(members_with_issues) - 5} anggota lainnya")
            
            # Konfirmasi perbaikan
            print(f"\n⚠️  Akan memperbaiki {len(members_with_issues)} anggota")
            confirm = input("Lanjutkan perbaikan? (y/n): ").lower().strip()
            
            if confirm == 'y':
                # Perbaiki semua ketidaksesuaian
                total_corrections = fixer.fix_all_discrepancies(members_with_issues)
                
                # Verifikasi hasil
                fixer.verify_final_results()
            else:
                print("❌ Perbaikan dibatalkan")
        else:
            print("✅ Tidak ada anggota lain yang bermasalah")
        
        # Verifikasi final
        fixer.verify_final_results()
        
    except KeyboardInterrupt:
        print("\n⏹️  Perbaikan dihentikan oleh user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        fixer.close_connection()

if __name__ == "__main__":
    main()
